 -------- < aula10extra1 > --------
--
--                    SCRIPT DE CONSULTA (DML)
--
-- Data Criacao ...........: 22/11/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 4 consultas
-- 
-- Ultimas Alteracoes
--  22/11/2023 => Criação do SCRIPT para consultar dados da base de dados referente ao exercicio extra 1 da aula 10
--
-- ---------------------------------------------------------

USE aula10extra1;

-- Primeira consulta - Letra a): Projeção de sigla e nome do estado de sigla SP e DF
SELECT sigla, nome
FROM ESTADO
WHERE sigla IN ('SP', 'DF');

-- Segunda consulta - Letra b): Selecione somente o nome e a sigla das cidades que são dos estados RJ, DF e GO
SELECT nome, sigla
FROM CIDADE
WHERE sigla IN ('RJ', 'DF', 'GO');

-- Terceira consulta - Letra c): Selecione todas as cidades do primeiro estado que você cadastrou mostrando somente o nome da cidade, o nome do estado e sua sigla
SELECT CIDADE.nome, ESTADO.nome, ESTADO.sigla
FROM CIDADE
JOIN ESTADO ON CIDADE.sigla = ESTADO.sigla
ORDER BY ESTADO.codigo, CIDADE.codigo
LIMIT 1;

-- Quarta consulta - Letra d): Selecione somente o nome e a sigla do estado que você cadastrou por último e todas as cidades cadastradas nele, mostrando o seu nome e a quantidade de habitantes em ordem crescente de nome de estado e nome de cidade.
SELECT ESTADO.nome, ESTADO.sigla, CIDADE.nome, CIDADE.habitantes
FROM CIDADE
JOIN ESTADO ON CIDADE.sigla = ESTADO.sigla
WHERE ESTADO.sigla = (
    SELECT sigla
    FROM ESTADO
    ORDER BY codigo DESC
    LIMIT 1
)
ORDER BY ESTADO.nome, CIDADE.nome;