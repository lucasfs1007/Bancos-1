﻿-- -------- < aula10extra1> --------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 22/11/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 2 tabelas
-- 
-- Ultimas Alteracoes
--  22/11/2023 => Criação do SCRIPT para popular as tabelas
--
-- ---------------------------------------------------------

USE aula10extra1;

INSERT INTO ESTADO (sigla, nome) VALUES
	('RJ', 'Rio de Janeiro'),
	('SP', 'São Paulo'),
    ('AM', 'Amazonas'),
    ('DF', 'Distrito Federal'),
	('PB', 'Paraiba'),
    ('GO', 'Goiás');
    

INSERT INTO CIDADE (nome, habitantes, sigla) VALUES
	('Rio de Janeiro', 16000000, 'RJ'),
	('São Paulo', 4900000, 'SP'),
	('Manaus', 2500000, 'AM'),
	('Campinas', 1200000, 'SP'),
	('Valparaíso', 500000, 'GO'),
	('João Pessoa', 700000, 'PB'),
	('Santos', 430000, 'SP'),
    ('Taguatinga', 300000, 'DF'),
    ('Goiânia', 1500000, 'GO'),
	('Brasília', 3000000, 'DF'),
    ('Anápolis', 400000, 'GO'),
    ('Ceilândia', 500000, 'DF'),
    ('Luziânia', 200000, 'GO'),
    ('Guará', 150000, 'DF');