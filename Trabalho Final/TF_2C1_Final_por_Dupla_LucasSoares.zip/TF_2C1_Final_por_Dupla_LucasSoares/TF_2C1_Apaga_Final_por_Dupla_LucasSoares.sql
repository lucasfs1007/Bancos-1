-- ---------------------------------------------------------
-- -------- <TF_2C1_Apaga_Final_por_Dupla_LucasSoares > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 02/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 25 Tabelas
--         => 02 Usuarios
-- 
-- Ultimas Alteracoes
--   02/12/2023 => Criacao do Script de deleção
--   /12/2023 => Organizando as tabelas na priorização de deletes
-- ---------------------------------------------------------
USE TF_2C1_LucasSoares;

DROP TABLE RELATORIO_PACIENTE;
DROP TABLE PACIENTE;
DROP TABLE CONTRATO_PACIENTE;
DROP TABLE PAGAMENTO;
DROP TABLE RELATORIO_ALUNO;
DROP TABLE ALUNO;
DROP TABLE SECRETARIO;
DROP TABLE CONTRATO;
DROP TABLE CLIENTE;
DROP TABLE RELATORIO;
DROP TABLE AULA;
DROP TABLE ESTAGIARIO;
DROP TABLE EDUCADOR_FISICO;
DROP TABLE FISIOTERAPEUTA;
DROP TABLE PROFESSOR;
DROP TABLE SALARIO;
DROP TABLE PONTO;
DROP TABLE LAUDO_MEDICO;
DROP TABLE MODALIDADE;
DROP TABLE PLANO_SAUDE;
DROP TABLE FINANCEIRO;
DROP TABLE ADMINISTRACAO;
DROP TABLE FUNCIONARIO;
DROP TABLE PESSOA;