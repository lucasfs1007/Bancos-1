-- ---------------------------------------------------------
-- -------- < TF_2C1_Popula_Final_por_Dupla_LucasSoares > --------
--
--                    SCRIPT DE POPULA
--
-- Data Criacao ...........: 02/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 25 Tabelas
--         => 02 Usuarios
-- 
-- Ultimas Alteracoes
--   02/12/2023 => Preenchendo 5 tuplas para cada tabela
-- ---------------------------------------------------------

USE TF_2C1_LucasSoares;

INSERT INTO PESSOA (cpf, nomeCompleto, rg, cep, numero, bairro, dtNascimento, telefone, email) VALUES
('111.222.333-44', 'Ana Silva', '12345678', '12345-678', '123', 'Centro', '1990-05-15', '(11) 98765-4321', 'ana.silva@email.com'),
('222.333.444-55', 'Carlos Oliveira', '87654321', '56789-012', '456', 'Bairro A', '1985-10-22', '(22) 12345-6789', 'carlos.oliveira@email.com'),
('333.444.555-66', 'Fernanda Santos', '56781234', '98765-432', '789', 'Bairro B', '1978-12-15', '(33) 5555-6666', 'fernanda.santos@email.com'),
('444.555.666-77', 'José Souza', '98761234', '54321-876', '321', 'Bairro C', '1988-08-20', '(44) 8765-4321', 'jose.souza@email.com'),
('555.666.777-88', 'Mariana Pereira', '34567890', '87654-321', '654', 'Bairro D', '1995-03-10', '(55) 7654-3210', 'mariana.pereira@email.com');

INSERT INTO CLIENTE (matricula, taxaMatricula, motivo, necessidadesEspeciais, sexo, status, dtInicio, frequencia, idRelatorio)
VALUES
(123456, 150.00, 'Melhorar a postura', 'Nenhuma', 'M', 'Ativo', '2022-01-05', 3, 1),
(234567, 150.00, 'Reabilitação pós-lesão', 'Nenhuma', 'F', 'Ativo', '2021-11-15', 4, 2),
(345678, 150.00, 'Aliviar dores nas costas', 'Nenhuma', 'M', 'Ativo', '2022-02-20', 2, 3),
(456789, 150.00, 'Prevenir lesões', 'Nenhuma', 'F', 'Ativo', '2022-03-10', 3, 4),
(567890, 150.00, 'Fortalecimento muscular', 'Lesão no ombro', 'M', 'Ativo', '2021-09-08', 5, 5);

INSERT INTO ALUNO (idAluno, idContratoAluno, cpf) VALUES
(1, 101, '111.222.333-44'),
(2, 102, '222.333.444-55'),
(3, 103, '333.444.555-66'),
(4, 104, '444.555.666-77'),
(5, 105, '555.666.777-88');

INSERT INTO PACIENTE (idPaciente, idContratoPaciente, numeroCarteirinha, laudo, trauma, idLaudo) VALUES
(1, 201, 123456, 'Paciente buscando melhoria na postura e flexibilidade', 'Nenhum trauma conhecido', 301),
(2, 202, 789012, 'Paciente em reabilitação pós-lesão na Academia', 'Lesão no tornozelo durante a prática esportiva', 302),
(3, 203, 345678, 'Paciente em busca de fortalecimento muscular com Pilates', 'Nenhum trauma conhecido', 303),
(4, 204, 901234, 'Paciente praticante de Pilates com histórico de lesões no ombro', 'Lesão no ombro durante atividade física', 304),
(5, 205, 567890, 'Paciente em tratamento de dores após fratura no braço', 'Fratura no braço durante acidente de carro', 305);

INSERT INTO FUNCIONARIO (matricula, dtAdmissao, salario, cursos, cargaHoraria, escolaridade, funcao, responsabilidade)
VALUES
(1001, '2022-01-15', 3500.000, 'Certificação em Pilates Avançado', 40, 'Bacharel em Fisioterapia', 'Professor', 'Ministrar aulas'),
(1002, '2021-08-20', 4000.000, 'Curso de Fisioterapia Desportiva', 40, 'Mestrado em Fisioterapia', 'Professor', 'Ministrar aulas'),
(1003, '2022-03-05', 3000.000, 'Curso de Atendimento ao Público', 40, 'Bacharel e Administração', 'Secretario', 'Atendimento ao público'),
(1004, '2021-11-10', 3800.000, 'Certificação em recomposição muscular', 40, 'Bacharel em Educação Física', 'Professor', 'Ministrar aulas'),
(1005, '2022-02-01', 1500.000, 'Nenhum', 30, 'Ensino Médio Completo', 'Estagiario', 'Auxiliar os professores nas aulas'),
(1006, '2022-04-01', 3200.000, 'Curso de Atendimento ao Público', 40, 'Bacharel em Administração', 'Secretário', 'Atendimento ao público'),
(1007, '2022-05-10', 3300.000, 'Curso de Atendimento ao Público', 40, 'Bacharel em Administração', 'Secretário', 'Atendimento ao público'),
(1008, '2022-06-15', 3100.000, 'Curso de Atendimento ao Público', 40, 'Bacharel em Administração', 'Secretário', 'Atendimento ao público'),
(1009, '2022-07-20', 3400.000, 'Curso de Atendimento ao Público', 40, 'Bacharel em Administração', 'Secretário', 'Atendimento ao público'),
(1014, '2023-01-01', 4500.000, 'Curso de Fisioterapia Desportiva Avançada', 40, 'Mestrado em Fisioterapia', 'Professor', 'Ministrar aulas'),
(1015, '2023-02-10', 4200.000, 'Certificação em Acupuntura', 40, 'Bacharel em Fisioterapia', 'Professor', 'Ministrar aulas'),
(1016, '2023-03-15', 4600.000, 'Curso de Quiropraxia', 40, 'Mestrado em Fisioterapia', 'Professor', 'Ministrar aulas'),
(1017, '2023-04-20', 4300.000, 'Curso de Pilates para Fisioterapeutas', 40, 'Mestrado em Fisioterapia', 'Fisioterapeuta', 'Ministrar aulas'),
(1018, '2023-05-01', 800.000, 'Nenhum', 30, 'Ensino Médio Completo', 'Estagiário', 'Auxiliar nas atividades diárias.'),
(1019, '2023-06-10', 800.000, 'Nenhum', 30, 'Ensino Médio Completo', 'Estagiário', 'Auxiliar nas atividades diárias.'),
(1020, '2023-07-15', 800.000, 'Nenhum', 30, 'Ensino Médio Completo', 'Estagiário', 'Auxiliar nas atividades diárias.'),
(1021, '2023-08-20', 800.000, 'Nenhum', 30, 'Ensino Médio Completo', 'Estagiário', 'Auxiliar nas atividades diárias.'),
(1022, '2023-09-01', 3800.000, 'Curso Avançado de Pilates', 40, 'Bacharel em Educação Física', 'Professor', 'Ministrar aulas'),
(1023, '2023-10-15', 4100.000, 'Curso Avançado de Pilates', 40, 'Bacharel em Educação Física', 'Professor', 'Ministrar aulas'),
(1024, '2023-11-20', 3900.000, 'Curso Avançado de Pilates', 40, 'Bacharel em Educação Física', 'Professor', 'Ministrar aulas'),
(1025, '2023-12-05', 4200.000, 'Curso Avançado de Pilates', 40, 'Bacharel em Educação Física', 'Professor', 'Ministrar aulas');

INSERT INTO PROFESSOR (matriculaProfessor, idAula)
VALUES
(1001, 1),
(1002, 2),
(1004, 3), 
(1014, 4), 
(1015, 5), 
(1016, 6), 
(1017, 7),
(1022, 8),
(1023, 9),
(1024,10),
(1025,11); 

INSERT INTO FISIOTERAPEUTA ( crefito, idModalidade )	VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4),
	(5, 5);

INSERT INTO EDUCADOR_FISICO (cref, idModalidade)
VALUES
('CREF001-SP', 1), 
('CREF002-RJ', 2), 
('CREF003-MG', 3),
('CREF004-BA', 4), 
('CREF005-PR', 5); 

INSERT INTO  ADMINISTRACAO ( matriculaAdmin, cursoAdministrativo )
 VALUES
(1003, 'Curso de Atendimento ao Público'),
(1006, 'Curso de Atendimento ao Público'), 
(1007, 'Curso de Atendimento ao Público'), 
(1008, 'Curso de Atendimento ao Público'), 
(1009, 'Curso de Atendimento ao Público'); 

INSERT INTO FINANCEIRO(idFinanceiro, reciboTransacoes, caixa, gastosFixos, gastosVariaveis, pagamentoFuncionario, eventos, bonificacoes, pagamentoAluno) VALUES
	(1, 100, 2000.00, 500.00, 300.00, 1500.00, 'Evento 1', 200.00, 1000.00),
	(2, 101, 1800.00, 450.00, 250.00, 1400.00, 'Evento 2', 180.00, 950.00),
	(3, 102, 2200.00, 600.00, 350.00, 1700.00, 'Evento 3', 250.00, 1200.00),
	(4, 103, 2500.00, 700.00, 400.00, 2000.00, 'Evento 4', 300.00, 1500.00),
	(5, 104, 1900.00, 550.00, 300.00, 1600.00, 'Evento 5', 220.00, 1050.00);

INSERT INTO  SECRETARIO(idSecretario, idContrato, idAluno) 
VALUES
(1003, 'Curso de Atendimento ao Público'),
(1006, 'Curso de Atendimento ao Público'), 
(1007, 'Curso de Atendimento ao Público'), 
(1008, 'Curso de Atendimento ao Público'), 
(1009, 'Curso de Atendimento ao Público'); 

INSERT INTO ESTAGIARIO (idEstagiario, orientador, vinculo, status)
VALUES
(1005, 'Ana Silva', 'Vínculo Estagiário', 'Ativo'), 
(1018, 'Ana Silva', 'Vínculo Estagiário', 'Ativo'), 
(1019, 'Ana Silva', 'Vínculo Estagiário', 'Ativo'), 
(1020, 'Ana Silva', 'Vínculo Estagiário', 'Ativo'), 
(1021, 'Ana Silva', 'Vínculo Estagiário', 'Ativo'); 

-- Adicionando registros à tabela PLANO_SAUDE
INSERT INTO PLANO_SAUDE (numeroCarteirinha, nomeCompleto, guia, reembolso)
VALUES
(123456789, 'Nome Completo 1', 'Guia 1', 80.00),
(987654321, 'Nome Completo 2', 'Guia 2', 75.50),
(456789123, 'Nome Completo 3', 'Guia 3', 90.25),
(789123456, 'Nome Completo 4', 'Guia 4', 85.75),
(321654987, 'Nome Completo 5', 'Guia 5', 70.00);

INSERT INTO MODALIDADE (idModalidade, nomeModalidade, tipoModalidade, descricao)
VALUES
(1, 'Pilates Solo', 'Pilates', 'Modalidade de Pilates realizada individualmente sem equipamentos.'),
(2, 'Pilates com Aparelhos', 'Pilates', 'Modalidade de Pilates que utiliza equipamentos específicos para os exercícios.'),
(3, 'Pilates Clínico', 'Pilates', 'Modalidade de Pilates adaptada para reabilitação física e tratamento de lesões.'),
(4, 'Pilates para Gestantes', 'Pilates', 'Modalidade de Pilates desenvolvida para atender gestantes, adaptando os exercícios para essa fase.'),
(5, 'Pilates Avançado', 'Pilates', 'Modalidade de Pilates com exercícios mais desafiadores e intensos.');

INSERT INTO AULA(idAula, horaInicio, horaFim, frequencia, idAluno, crefito, cref, idRelatorio) VALUES
	(1, '09:00:00', '10:00:00', 'P', 1, NULL, NULL, 1),
	(2, '10:30:00', '11:30:00', 'F', 2, 302, NULL, 2),
	(3, '14:00:00', '15:00:00', 'P', 3, NULL,  'CREF001-SP', 3),
	(4, '16:30:00', '17:30:00', 'F', 4, 304, NULL, 4),
	(5, '18:00:00', '19:00:00', 'P', 5, NULL, 'CREF002-RJ', 5);

INSERT INTO RELATORIO(idRelatorio, idAula,crefito, matricula, avaliacao, objetivo, progresso, dataRelatorio, assinatura) VALUES
	(1, 1, NULL, '111.222.333-44', 'Avaliação inicial', 'Melhorar postura', 'Progresso satisfatório', '2023-02-15', 'Assinatura 1'),
	(2, 2, 302, '222.333.444-55', 'Avaliação intermediária', 'Reabilitação pós-lesão', 'Bom progresso observado', '2023-02-28', 'Assinatura 2'),
	(3, 3, NULL, '333.444.555-66', 'Avaliação inicial', 'Fortalecimento muscular', 'Progresso excelente', '2023-03-10', 'Assinatura 3'),
	(4, 4, 304, '444.555.666-77', 'Avaliação final', 'Prevenção de lesões', 'Progresso notável', '2023-03-25', 'Assinatura 4'),
	(5, 5, NULL, '555.666.777-88', 'Avaliação intermediária', 'Fortalecimento muscular avançado', 'Progresso acima da média', '2023-04-05', 'Assinatura 5');

INSERT INTO RELATORIO_ALUNO ( idRelatorioAluno, idAluno, recomendacao ) VALUES
	(1, 1, 'Continuar com os exercícios regularmente.'),
	(2, 2, 'Ajustar intensidade dos exercícios de acordo com a recuperação.'),
	(3, 3, 'Incluir mais exercícios específicos para a necessidade de fortalecimento.'),
	(4, 4, 'Manter rotina de exercícios e prevenção de lesões.'),
	(5, 5, 'Progredir para exercícios mais avançados.');

INSERT INTO RELATORIO_PACIENTE ( idRelatorioPaciente, idPaciente, numeroCarteirinha, laudo, trauma, tratamento, historicoMedico, recomendacaoMedica) VALUES
	(1, 1, 123456, 'Melhoria na postura e flexibilidade', 'Nenhum trauma conhecido', 'Exercícios específicos para os objetivos', 'Nenhum histórico médico significativo', 'Seguir orientações para manutenção da saúde'),
	(2, 2, 789012, 'Reabilitação pós-lesão na Academia', 'Lesão no tornozelo durante a prática esportiva', 'Exercícios adaptados para a lesão', 'Histórico de lesões no tornozelo', 'Continuar tratamento conforme orientação médica'),
	(3, 3, 345678, 'Fortalecimento muscular com Pilates', 'Nenhum trauma conhecido', 'Rotina de exercícios específicos para fortalecimento', 'Nenhum histórico médico significativo', 'Manter regularidade nos exercícios e avaliações médicas'),
	(4, 4, 901234, 'Praticante de Pilates com histórico de lesões no ombro', 'Lesão no ombro durante atividade física', 'Exercícios adaptados para evitar impacto no ombro', 'Histórico de lesões no ombro', 'Evitar atividades que possam causar impacto no ombro'),
	(5, 5, 567890, 'Tratamento de dores após fratura no braço', 'Fratura no braço durante acidente de carro', 'Exercícios para reabilitação do braço', 'Histórico de fratura no braço', 'Seguir orientações para reabilitação do braço.');

INSERT INTO LAUDO_MEDICO(idLaudo, nomeLaudo, dataEmissao, nomeMedico, numeroCrm, estado) VALUES
	(301, 'Laudo de Avaliação Fisioterapêutica', '2023-02-20', 'Dr. Fisio', 123456, 'SP'),
	(302, 'Laudo de Reabilitação Fisioterapêutica', '2023-03-01', 'Dra. Reabilita', 789012, 'RJ'),
	(303, 'Laudo de Avaliação Fisioterapêutica', '2023-03-15', 'Dr. Fisio', 345678, 'MG'),
	(304, 'Laudo de Prevenção de Lesões', '2023-03-30', 'Dra. Preveni', 901234, 'BA'),
	(305, 'Laudo de Reabilitação Fisioterapêutica', '2023-04-10', 'Dr. Reabilita', 567890, 'PR');

INSERT INTO CONTRATO(idContrato, idAluno, idAula, matricula, taxaMatricula, valor ) VALUES
	(101, 1, 1, '111.222.333-44', 150.00, 1200.00),
	(102, 2, 2, '222.333.444-55', 150.00, 1300.00),
	(103, 3, 3, '333.444.555-66', 150.00, 1100.00),
	(104, 4, 4, '444.555.666-77', 150.00, 1400.00),
	(105, 5, 5, '555.666.777-88', 150.00, 1250);

INSERT INTO CONTRATO_PACIENTE(idContratoPaciente, idPaciente, reembolso) VALUES
	(101, 1, 50.00),
	(102, 2, 30.00),
	(103, 3, 40.00),
	(104, 4, 60.00),
	(105, 5, 45.00);

INSERT INTO PONTO(idPonto, matricula, horaEntrada, horaSaida) VALUES
	(1, '111.222.333-44', '08:45:00', '10:15:00'),
	(2, '222.333.444-55', '10:30:00', '12:00:00'),
	(3, '333.444.555-66', '13:45:00', '15:15:00'),
	(4, '444.555.666-77', '16:15:00', '17:45:00'),
	(5, '555.666.777-88', '17:30:00', '19:00:00');

INSERT INTO SALARIO (idSalario, idPonto, matricula,dataPagamento) VALUES
	(1, 1, '111.222.333-44', '2023-02-28'),
	(2, 2, '222.333.444-55', '2023-02-28'),
	(3, 3, '333.444.555-66', '2023-02-28'),
	(4, 4, '444.555.666-77', '2023-02-28'),
	(5, 5, '555.666.777-88', '2023-02-28');

INSERT INTO PAGAMENTO(idPagamento, idContrato, dataEmissao, desconto, recibo) VALUES
	(1, 101, '2023-02-28', 20.00, 'Recibo001'),
	(2, 102, '2023-02-28', 15.00, 'Recibo002'),
	(3, 103, '2023-02-28', 10.00, 'Recibo003'),
	(4, 104, '2023-02-28', 25.00, 'Recibo004'),
	(5, 105, '2023-02-28', 18.00, 'Recibo005');

















