-- --------  << TF_2C1_LucasSoares >>  ----------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 06/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_2C1_LucasSoares;

-- Criação de papéis (roles)
CREATE ROLE administrador;
CREATE ROLE funcionario;

-- Atribuição de privilégios para o papel 'administrador'
-- GRANT ALL PRIVILEGES: Concede todos os privilégios disponíveis para o banco de dados e todas as tabelas.
-- ON TF_2C1_LucasSoares.*: Aplica a concessão de privilégios para todas as tabelas no banco de dados chamado TF_2C1_LucasSoares.
-- TO administrador: Atribui esses privilégios ao papel (role) chamado 'administrador'.
GRANT ALL PRIVILEGES ON TF_2C1_LucasSoares.* TO administrador;

-- Atribuição de privilégios para o papel 'funcionario'
-- GRANT SELECT: Concede o privilégio de SELECT, permitindo a leitura de dados nas tabelas.
-- GRANT INSERT: Concede o privilégio de INSERT, permitindo a inserção de novos registros nas tabelas.
GRANT SELECT ON TF_2C1_LucasSoares.* TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.CLIENTE TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.ALUNO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.PACIENTE TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.ESTAGIARIO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.MODALIDADE TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.AULA TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.RELATORIO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.RELATORIO_ALUNO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.RELATORIO_PACIENTE TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.LAUDO_MEDICO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.CONTRATO TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.CONTRATO_PACIENTE TO funcionario;
GRANT INSERT ON TF_2C1_LucasSoares.PONTO TO funcionario;

-- Criação de usuários e atribuição de papéis
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin123';
CREATE USER 'funcionario'@'localhost' IDENTIFIED BY 'func123';

GRANT administrador TO 'admin'@'localhost';
GRANT funcionario TO 'funcionario'@'localhost';