-- ---------------------------------------------------------
-- -------- <TF_2C_Apaga_Final_por_Grupo_LucasSoares > --------
--
--                    SCRIPT APAGA
----
-- Data Criacao ...........: 14/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira, Johnny da Ponte Lopes e Leonardo Ferreira Borges
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 28 Tabelas
--         => 03 Usuarios
-- 
-- Ultimas Alteracoes
--   14/12/2023 => Criacao do Script de deleção
--   15/12/2023 => Reajuste da ordem de deleção
--   17/12/2023 => Reajuste da ordem de deleção
---------------------------------------------------------
USE TF_2C_LucasSoares;

DROP TABLE ministra;
DROP TABLE participa;
DROP TABLE dispoe;
DROP TABLE possui;
DROP TABLE paga;
DROP TABLE bate;
DROP TABLE apresenta;
DROP TABLE detem;
DROP TABLE tem;
DROP TABLE ATESTADO;
DROP TABLE PAGAMENTO;
DROP TABLE RELATORIO_PACIENTE;
DROP TABLE RELATORIO_ALUNO;
DROP TABLE PONTO;
DROP TABLE SALARIO;
DROP TABLE CONTRATO;
DROP TABLE MODALIDADE;
DROP TABLE ESPECIALIDADE;
DROP TABLE AULA;
DROP TABLE SECRETARIO;
DROP TABLE GESTOR;
DROP TABLE ESTAGIARIO;
DROP TABLE PROFESSOR;
DROP TABLE PLANO_SAUDE;
DROP TABLE LAUDO_MEDICO;
DROP TABLE PACIENTE;
DROP TABLE ALUNO;
DROP TABLE DEPENDENTE;

-- Apagando os 3 usuários
DROP USER funcionario;
DROP USER administrador;
DROP USER gestor; 