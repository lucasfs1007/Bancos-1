-- ---------------------------------------------------------
-- -------- < TF_2C_LucasSoares > --------
--
--                    SCRIPT DE POPULA
--
-- Data Criacao ...........: 16/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira, Johnny da Ponte Lopes e Leonardo Ferreira Borges
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 22 Tabelas
--         => 02 Usuarios
-- 
-- Ultimas Alteracoes
-- 16/12/2023 => Criacao da base de preenchimento das tabelas
-- ---------------------------------------------------------

USE TF_2C_LucasSoares;

-- REVISAR SE TEM 10 DUPLAS EM CADA PRA PREENCHER, E SE OS ATRIBUTOS ESTÃO CORRETOS

INSERT INTO DEPENDENTE (nome, cpf, dataNascimento, telefone, email, sexo, parentesco, logradouro, numero, bairro, cidade, estado, cep)
VALUES
('João Silva', 12345678901, '2000-01-15', 98765432101, 'joao@example.com', 'M', 'Filho', 'Rua A', 123, 'Centro', 'CidadeA', 'AA', 12345678),
('Maria Oliveira', 23456789012, '1998-05-20', 98765432102, 'maria@example.com', 'F', 'Filha', 'Rua B', 456, 'BairroX', 'CidadeB', 'BB', 23456789),
('Pedro Santos', 34567890123, '1999-08-10', 98765432103, 'pedro@example.com', 'M', 'Filho', 'Avenida C', 789, 'BairroY', 'CidadeC', 'CC', 34567890),
('Ana Souza', 45678901234, '1997-03-25', 98765432104, 'ana@example.com', 'F', 'Filha', 'Rua D', 101, 'BairroZ', 'CidadeD', 'DD', 45678901),
('Lucas Oliveira', 56789012345, '2001-12-05', 98765432105, 'lucas@example.com', 'M', 'Filho', 'Avenida E', 567, 'BairroW', 'CidadeE', 'EE', 56789012),
('Mariana Lima', 67890123456, '1996-06-30', 98765432106, 'mariana@example.com', 'F', 'Filha', 'Rua F', 202, 'BairroV', 'CidadeF', 'FF', 67890123),
('Gabriel Pereira', 78901234567, '1995-02-18', 98765432107, 'gabriel@example.com', 'M', 'Filho', 'Avenida G', 876, 'BairroU', 'CidadeG', 'GG', 78901234),
('Camila Santos', 89012345678, '1994-07-22', 98765432108, 'camila@example.com', 'F', 'Filha', 'Rua H', 303, 'BairroT', 'CidadeH', 'HH', 89012345),
('Rafael Souza', 90123456789, '1993-11-14', 98765432109, 'rafael@example.com', 'M', 'Filho', 'Avenida I', 987, 'BairroS', 'CidadeI', 'II', 90123456),
('Fernanda Lima', 12345678909, '1992-04-27', 98765432100, 'fernanda@example.com', 'F', 'Filha', 'Rua J', 404, 'BairroR', 'CidadeJ', 'JJ', 12345670);

INSERT INTO ALUNO (nome, cpf, dataNascimento, telefone, email, sexo, frequencia, status, necessidadesEspeciais, motivo, taxaMatricula, matriculaCliente, dtInicio, logradouro, numero, bairro, cidade, estado, cep, disponibilidade)
VALUES
('Carlos Pereira', 34567890123, '1999-08-10', 98765432103, 'carlos@example.com', 'M', 3, 'ATIVO', 'Nenhuma', 'Gosto de esportes', 150.00, 12345, 'Avenida C', 789, 'BairroY', 'CidadeC', 'CC', 34567890, 'Segunda e Quarta das 14h às 16h'),
('Ana Souza', 45678901234, '1997-03-25', 98765432104, 'ana@example.com', 'F', 2, 'INATIVO', 'Alergia a pólen', 'Razões pessoais', 200.00, 56789, 'Rua D', 101, 'BairroZ', 'CidadeD', 'DD', 45678901),
('Lucas Oliveira', 56789012345, '2001-12-05', 98765432105, 'lucas@example.com', 'M', 4, 'ATIVO', 'Nenhuma', 'Gosto de música', 180.00, 23456, 'Avenida E', 567, 'BairroW', 'CidadeE', 'EE', 56789012),
('Mariana Lima', 67890123456, '1996-06-30', 98765432106, 'mariana@example.com', 'F', 3, 'ATIVO', 'Nenhuma', 'Gosto de dançar', 200.00, 78901, 'Rua F', 202, 'BairroV', 'CidadeF', 'FF', 67890123),
('Gabriel Pereira', 78901234567, '1995-02-18', 98765432107, 'gabriel@example.com', 'M', 5, 'ATIVO', 'Nenhuma', 'Gosto de pintura', 220.00, 89012, 'Avenida G', 876, 'BairroU', 'CidadeG', 'GG', 78901234),
('Camila Santos', 89012345678, '1994-07-22', 98765432108, 'camila@example.com', 'F', 2, 'INATIVO', 'Diabetes', 'Razões de saúde', 250.00, 90123, 'Rua H', 303, 'BairroT', 'CidadeH', 'HH', 89012345),
('Rafael Souza', 90123456789, '1993-11-14', 98765432109, 'rafael@example.com', 'M', 3, 'ATIVO', 'Nenhuma', 'Gosto de leitura', 200.00, 23456, 'Avenida I', 987, 'BairroS', 'CidadeI', 'II', 90123456),
('Fernanda Lima', 12345678909, '1992-04-27', 98765432100, 'fernanda@example.com', 'F', 4, 'ATIVO', 'Nenhuma', 'Gosto de teatro', 180.00, 56789, 'Rua J', 404, 'BairroR', 'CidadeJ', 'JJ', 12345670),
('Eduardo Martins', 23456789098, '2000-09-08', 98765432111, 'eduardo@example.com', 'M', 3, 'ATIVO', 'Nenhuma', 'Gosto de tecnologia', 200.00, 12345, 'Avenida K', 555, 'BairroP', 'CidadeK', 'KK', 23456789),
('Juliana Oliveira', 34567890187, '1998-01-12', 98765432122, 'juliana@example.com', 'F', 2, 'INATIVO', 'Asma', 'Razões de saúde', 250.00, 56789, 'Rua L', 777, 'BairroQ', 'CidadeL', 'LL', 34567890);
    
INSERT INTO PACIENTE (nome, cpf, dataNascimento, telefone, email, sexo, laudo, numeroCarteirinha, frequencia, status, necessidadesEspeciais, motivo, taxaMatricula, matriculaCliente, dtInicio, logradouro, numero, bairro, cidade, estado, cep, disponibilidade)
VALUES
('Carlos Pereira', 34567890123, '1999-08-10', 98765432103, 'carlos@example.com', 'M', 'Laudo A', 123456, 3, 'ATIVO', 'Nenhuma', 'Gosto de esportes', 150.00, 12345, 'Avenida C', 789, 'BairroY', 'CidadeC', 'CC', 34567890, 'Segunda e Quarta das 14h às 16h'),
('Ana Souza', 45678901234, '1997-03-25', 98765432104, 'ana@example.com', 'F', 'Laudo B', 234567, 2, 'INATIVO', 'Alergia a pólen', 'Razões pessoais', 200.00, 56789, 'Rua D', 101, 'BairroZ', 'CidadeD', 'DD', 45678901),
('Lucas Oliveira', 56789012345, '2001-12-05', 98765432105, 'lucas@example.com', 'M', 'Laudo C', 345678, 4, 'ATIVO', 'Nenhuma', 'Gosto de música', 180.00, 23456, 'Avenida E', 567, 'BairroW', 'CidadeE', 'EE', 56789012),
('Mariana Lima', 67890123456, '1996-06-30', 98765432106, 'mariana@example.com', 'F', 'Laudo D', 456789, 3, 'ATIVO', 'Nenhuma', 'Gosto de dançar', 200.00, 78901, 'Rua F', 202, 'BairroV', 'CidadeF', 'FF', 67890123),
('Gabriel Pereira', 78901234567, '1995-02-18', 98765432107, 'gabriel@example.com', 'M', 'Laudo E', 567890, 5, 'ATIVO', 'Nenhuma', 'Gosto de pintura', 220.00, 89012, 'Avenida G', 876, 'BairroU', 'CidadeG', 'GG', 78901234),
('Camila Santos', 89012345678, '1994-07-22', 98765432108, 'camila@example.com', 'F', 'Laudo F', 678901, 2, 'INATIVO', 'Diabetes', 'Razões de saúde', 250.00, 90123, 'Rua H', 303, 'BairroT', 'CidadeH', 'HH', 89012345),
('Rafael Souza', 90123456789, '1993-11-14', 98765432109, 'rafael@example.com', 'M', 'Laudo G', 789012, 3, 'ATIVO', 'Nenhuma', 'Gosto de leitura', 200.00, 23456, 'Avenida I', 987, 'BairroS', 'CidadeI', 'II', 90123456),
('Fernanda Lima', 12345678909, '1992-04-27', 98765432100, 'fernanda@example.com', 'F', 'Laudo H', 890123, 4, 'ATIVO', 'Nenhuma', 'Gosto de teatro', 180.00, 56789, 'Rua J', 404, 'BairroR', 'CidadeJ', 'JJ', 12345670),
('Eduardo Martins', 23456789098, '2000-09-08', 98765432111, 'eduardo@example.com', 'M', 'Laudo I', 901234, 3, 'ATIVO', 'Nenhuma', 'Gosto de tecnologia', 200.00, 12345, 'Avenida K', 555, 'BairroP', 'CidadeK', 'KK', 23456789),
('Juliana Oliveira', 34567890187, '1998-01-12', 98765432122, 'juliana@example.com', 'F', 'Laudo J', 1234567, 2, 'INATIVO', 'Asma', 'Razões de saúde', 250.00, 56789, 'Rua L', 777, 'BairroQ', 'CidadeL', 'LL', 34567890);

INSERT INTO SALARIO (dataPagamento, valor, idProfessor, idEstagiario, idSecretario)
VALUES
('2023-11-30', 5000.00, 1, NULL, NULL),
('2023-12-07', 3500.00, 2, NULL, NULL),
('2023-12-14', 2800.00, 3, NULL, NULL),
('2023-11-25', 2000.00, NULL, 1, NULL),
('2023-12-02', 1500.00, NULL, 2, NULL),
('2023-12-09', 1200.00, NULL, 3, NULL),
('2023-12-16', 4500.00, 1, NULL, 1),
('2023-12-11', 3000.00, 2, NULL, 2),
('2023-12-18', 2500.00, 3, NULL, 3),
('2023-11-20', 1800.00, NULL, 1, 1);

INSERT INTO SECRETARIO (
    dtAdmissao, 
    responsabilidade, 
    escolaridade, 
    cargaHoraria, 
    cursos, 
    funcao, 
    cep, 
    logradouro, 
    estado, 
    cidade, 
    bairro, 
    numero, 
    nome, 
    telefone, 
    cpf, 
    email, 
    dataNascimento, 
    sexo
) VALUES 
('2022-01-15', 'Atendimento ao cliente', 'Ensino Médio Completo', 40, 'Curso1, Curso2', 'Atendente', 12345678, 'Rua A', 'SP', 'Cidade1', 'Bairro1', 123, 'Secretario1', 98765432101, 12345678901, 'secretario1@email.com', '1990-01-01', 'M'),
('2022-02-20', 'Gestão de documentos', 'Ensino Superior Completo', 35, 'Curso3, Curso4', 'Assistente', 23456789, 'Rua B', 'RJ', 'Cidade2', 'Bairro2', 456, 'Secretario2', 87654321012, 23456789012, 'secretario2@email.com', '1985-05-15', 'F'),
('2022-03-25', 'Coordenação de eventos', 'Ensino Médio Completo', 30, 'Curso5, Curso6', 'Coordenador', 34567890, 'Rua C', 'MG', 'Cidade3', 'Bairro3', 789, 'Secretario3', 76543210923, 34567890123, 'secretario3@email.com', '1988-08-20', 'M'),
('2022-04-10', 'Gestão financeira', 'Ensino Superior Completo', 40, 'Curso7, Curso8', 'Analista Financeiro', 45678901, 'Rua D', 'PR', 'Cidade4', 'Bairro4', 101, 'Secretario4', 65432109834, 45678901234, 'secretario4@email.com', '1992-12-10', 'F'),
('2022-05-30', 'Atendimento ao público', 'Ensino Médio Completo', 35, 'Curso9, Curso10', 'Atendente', 56789012, 'Rua E', 'SC', 'Cidade5', 'Bairro5', 112, 'Secretario5', 54321098745, 56789012345, 'secretario5@email.com', '1982-03-25', 'M'),
('2022-06-15', 'Gestão de projetos', 'Ensino Superior Completo', 30, 'Curso11, Curso12', 'Analista de Projetos', 67890123, 'Rua F', 'BA', 'Cidade6', 'Bairro6', 223, 'Secretario6', 43210987656, 67890123456, 'secretario6@email.com', '1987-07-05', 'F'),
('2022-07-30', 'Recursos Humanos', 'Ensino Superior Completo', 40, 'Curso13, Curso14', 'Analista de RH', 78901234, 'Rua G', 'GO', 'Cidade7', 'Bairro7', 334, 'Secretario7', 32109876567, 78901234567, 'secretario7@email.com', '1995-09-30', 'M'),
('2022-08-12', 'Assistência administrativa', 'Ensino Médio Completo', 35, 'Curso15, Curso16', 'Assistente Administrativo', 89012345, 'Rua H', 'RS', 'Cidade8', 'Bairro8', 445, 'Secretario8', 21098765478, 89012345678, 'secretario8@email.com', '1983-04-12', 'F'),
('2022-09-18', 'Comunicação interna', 'Ensino Superior Completo', 30, 'Curso17, Curso18', 'Analista de Comunicação', 90123456, 'Rua I', 'PE', 'Cidade9', 'Bairro9', 556, 'Secretario9', 10987654389, 90123456789, 'secretario9@email.com', '1989-06-18', 'M'),
('2022-10-08', 'Atendimento telefônico', 'Ensino Médio Completo', 40, 'Curso19, Curso20', 'Atendente', 12345670, 'Rua J', 'MA', 'Cidade10', 'Bairro10', 667, 'Secretario10', 98765432109, 12345678901, 'secretario10@email.com', '1991-11-08', 'F');

INSERT INTO AULA (horaInicio, horaFim, frequencia, idEstagiario)
VALUES 
('08:00:00', '09:30:00', 3, 1),
('10:00:00', '11:30:00', 2, 2),
('13:00:00', '14:30:00', 1, 3),
('15:00:00', '16:30:00', 3, 4),
('09:00:00', '10:30:00', 2, 5),
('11:00:00', '12:30:00', 1, 1),
('14:00:00', '15:30:00', 3, 2),
('16:00:00', '17:30:00', 2, 3),
('08:30:00', '10:00:00', 1, 4),
('10:30:00', '12:00:00', 3, 5);

INSERT INTO GESTOR (
    nome, 
    cpf, 
    dataNascimento, 
    telefone, 
    email, 
    sexo, 
    pagamentoFuncionario, 
    reciboTransacoes, 
    eventos, 
    caixa, 
    gastosVariaveis, 
    gastosFixos, 
    bonificacoes, 
    logradouro, 
    numero, 
    bairro, 
    cidade, 
    estado, 
    cep
) VALUES 
('Gestor1', 12345678901, '1990-01-01', 98765432101, 'gestor1@email.com', 'M', 3000.000, 'Recibo1', 'Evento1', 5000.000, 1000.000, 2000.000, 500.000, 'Rua A', 123, 'Bairro1', 'Cidade1', 'SP', 12345678),
('Gestor2', 23456789012, '1985-05-15', 87654321012, 'gestor2@email.com', 'F', 3500.000, 'Recibo2', 'Evento2', 5500.000, 1200.000, 1800.000, 600.000, 'Rua B', 456, 'Bairro2', 'Cidade2', 'RJ', 23456789),
('Gestor3', 34567890123, '1988-08-20', 76543210923, 'gestor3@email.com', 'M', 4000.000, 'Recibo3', 'Evento3', 6000.000, 1100.000, 2200.000, 550.000, 'Rua C', 789, 'Bairro3', 'Cidade3', 'MG', 34567890),
('Gestor4', 45678901234, '1992-12-10', 65432109834, 'gestor4@email.com', 'F', 3200.000, 'Recibo4', 'Evento4', 5200.000, 1300.000, 1900.000, 580.000, 'Rua D', 101, 'Bairro4', 'Cidade4', 'PR', 45678901),
('Gestor5', 56789012345, '1982-03-25', 54321098745, 'gestor5@email.com', 'M', 3800.000, 'Recibo5', 'Evento5', 5800.000, 1050.000, 2100.000, 520.000, 'Rua E', 112, 'Bairro5', 'Cidade5', 'SC', 56789012),
('Gestor6', 67890123456, '1987-07-05', 43210987656, 'gestor6@email.com', 'F', 4200.000, 'Recibo6', 'Evento6', 6200.000, 1250.000, 2000.000, 600.000, 'Rua F', 223, 'Bairro6', 'Cidade6', 'BA', 67890123),
('Gestor7', 78901234567, '1995-09-30', 32109876567, 'gestor7@email.com', 'M', 3500.000, 'Recibo7', 'Evento7', 5500.000, 1000.000, 2300.000, 480.000, 'Rua G', 334, 'Bairro7', 'Cidade7', 'GO', 78901234),
('Gestor8', 89012345678, '1983-04-12', 21098765478, 'gestor8@email.com', 'F', 3900.000, 'Recibo8', 'Evento8', 5900.000, 1200.000, 1800.000, 550.000, 'Rua H', 445, 'Bairro8', 'Cidade8', 'RS', 89012345),
('Gestor9', 90123456789, '1989-06-18', 10987654389, 'gestor9@email.com', 'M', 4400.000, 'Recibo9', 'Evento9', 6400.000, 1100.000, 2200.000, 520.000, 'Rua I', 556, 'Bairro9', 'Cidade9', 'PE', 90123456),
('Gestor10', 12345678901, '1991-11-08', 98765432109, 'gestor10@email.com', 'F', 3700.000, 'Recibo10', 'Evento10', 5700.000, 1300.000, 1900.000, 580.000, 'Rua J', 667, 'Bairro10', 'Cidade10', 'MA', 12345670);

INSERT INTO ESPECIALIDADE (nomeEspecialidade)
VALUES
('Pilates Clássico'),
('Graft'),
('Columbwall'),
('Graft'),
('Pilates Clássico'),
('Columbwall'),
('Pilates Clássico'),
('Columbwall'),
('Graft'),
('Pilates Clássico');

INSERT INTO PLANO_SAUDE (nome, guia, reembolso, numeroCarteirinha) VALUES
('Saúde Premium', 'ABC123DEF456', 0.80, 1234567890123456),
('Familiar Essencial', 'GHI789JKL012', 0.75, 9876543210987654),
('Individual Bronze', 'MNO345PQR678', 0.65, 0987654321012345),
('Empresarial Gold', 'STU901VWX234', 0.90, 1234567890987654),
('Aposentado Especial', 'DEF123GHI456', 0.85, 9876543210098765),
('Jovem Universitário', 'JKL567MNO890', 0.70, 0123456789012345),
('Completo Silver', 'PQR901STU234', 0.80, 9876543210123456),
('Familiar Econômico', 'VWX345DEF678', 0.60, 1234567890098765),
('Empresarial Platinum', 'GHI123JKL456', 0.95, 0987654321987654),
('Individual Prata', 'MNO678PQR901', 0.75, 0123456789987654);

INSERT INTO CONTRATO (
    taxaMatricula, valor, tipoContrato, idSecretarioElabora, idProfessor, idEstagiario, idSecretario, idAluno, idPaciente
) VALUES 
(50.00, 500.123, 'ADESÃO', 1, 2, NULL, 3, NULL, NULL),
(30.00, 400.234, 'CONTRATAÇÃO', 2, NULL, 1, NULL, 4, NULL),
(40.00, 600.345, 'ADESÃO', 3, NULL, NULL, NULL, NULL, 1),
(25.00, 350.456, 'ADESÃO', 4, NULL, 2, NULL, NULL, 3),
(60.00, 700.567, 'CONTRATAÇÃO', 1, 3, NULL, 2, NULL, 5),
(45.00, 550.678, 'ADESÃO', 2, NULL, 3, NULL, 5, NULL),
(55.00, 450.789, 'CONTRATAÇÃO', 3, 1, NULL, NULL, 6, NULL),
(35.00, 300.890, 'ADESÃO', 4, NULL, 4, 1, NULL, NULL),
(70.00, 800.901, 'CONTRATAÇÃO', 1, NULL, 5, NULL, NULL, 2),
(20.00, 200.012, 'ADESÃO', 2, NULL, NULL, 4, 7, NULL);

INSERT INTO PONTO (horaSaida, horaEntrada, idSalario)
VALUES 
('08:00:00', '17:00:00', 1),
('09:30:00', '18:00:00', 2),
('07:45:00', '16:30:00', 3),
('10:15:00', '19:00:00', 1),
('08:30:00', '17:15:00', 2),
('09:00:00', '18:30:00', 3),
('08:15:00', '17:45:00', 1),
('09:45:00', '18:15:00', 2),
('08:45:00', '17:30:00', 3),
('10:00:00', '19:30:00', 1);

INSERT INTO RELATORIO_ALUNO (recomendacao, avaliacao, progresso, assinatura, objetivo, dataRelatorio, idProfessor, idAluno)
VALUES
('Foco nas atividades aeróbicas, aumentar a intensidade gradualmente.', 'Bom desempenho geral, destaque em exercícios de cardio.', 'Melhoria constante nas últimas semanas, parabéns!', 'Ass. Prof. Silva', 'Melhorar resistência cardiovascular', '2023-03-01', 1, 1),
('Necessário reavaliar plano de treino devido à inatividade.', 'Desempenho anterior era melhor, investigar possíveis razões.', 'Baixo progresso observado, reavaliar abordagem.', 'Ass. Prof. Oliveira', 'Recuperar níveis de condicionamento', '2023-03-02', 2, 2),
('Ótimo comprometimento, destaque em exercícios de força.', 'Desempenho geral acima da média, parabéns!', 'Evolução notável, continue assim!', 'Ass. Prof. Lima', 'Ganho de massa muscular', '2023-03-03', 3, 3),
('Participação consistente nas aulas, mas pode intensificar os treinos.', 'Desempenho estável, alguns pontos a melhorar.', 'Progresso moderado, atenção especial a determinados exercícios.', 'Ass. Prof. Souza', 'Melhorar resistência aeróbica', '2023-03-04', 4, 4),
('Destaque em exercícios de flexibilidade, mantenha o foco.', 'Bom desempenho global, progresso constante.', 'Avanço observado, especialmente em exercícios específicos.', 'Ass. Prof. Pereira', 'Aprimorar flexibilidade e equilíbrio', '2023-03-05', 5, 5),
('Alergia a pólen pode afetar desempenho, adaptações necessárias.', 'Acompanhamento cuidadoso, ajustes frequentes no plano de treino.', 'Melhoria observada em áreas específicas, continue assim!', 'Ass. Prof. Santos', 'Adaptações para lidar com alergia', '2023-03-06', 6, 6),
('Comprometimento notável, destaque em atividades de resistência.', 'Desempenho geral positivo, foco em melhorias contínuas.', 'Evolução constante, continue com os esforços.', 'Ass. Prof. Souza', 'Aprimorar resistência e força', '2023-03-07', 7, 7),
('Excelente desempenho em exercícios de expressão corporal.', 'Melhoria notável em várias áreas, parabéns!', 'Evolução constante, especialmente em atividades específicas.', 'Ass. Prof. Lima', 'Aprimorar habilidades de expressão', '2023-03-08', 8, 8),
('Comprometimento com o treino, destaque em atividades de tecnologia.', 'Desempenho geral positivo, foco em aprimorar áreas específicas.', 'Evolução constante, continue assim!', 'Ass. Prof. Martins', 'Desenvolver habilidades tecnológicas', '2023-03-09', 9, 9),
('Asma pode impactar o desempenho, plano de treino adaptado.', 'Acompanhamento cuidadoso devido à condição de saúde.', 'Progresso observado em áreas específicas, continue com cuidado.', 'Ass. Prof. Oliveira', 'Adaptações para lidar com asma', '2023-03-10', 10, 10);

INSERT INTO RELATORIO_PACIENTE (
    trauma, historicoMedico, recomendacaoMedica, tratamento, 
    avaliacao, progresso, assinatura, objetivo, dataRelatorio, idProfessor, idPaciente
) VALUES 
('Fratura na perna', 'Sem histórico médico significativo', 'Repouso e acompanhamento', 
 'Fisioterapia', 'Bom progresso', 'Dr. John Doe', 'Recuperação completa', '2023-01-15', 1, 1),
('Lesão na coluna', 'Histórico de problemas lombares', 'Cirurgia recomendada', 
 'Repouso e exercícios', 'Recuperação lenta', 'Dr. Jane Smith', 'Melhora gradual', '2023-02-20', 2, 2),
('Queimadura de segundo grau', 'Sem histórico médico significativo', 'Curativo e medicamentos', 
 'Acompanhamento dermatológico', 'Excelente recuperação', 'Dr. Alex Johnson', 'Cicatrização completa', '2023-03-10', 3, 3);
 
INSERT INTO PAGAMENTO (dataPagamento, valor, formaPagamento, idAluno, idPaciente, idPlanosaude)
VALUES
('2023-12-18', 50.00, 'PIX', 1, NULL, NULL),
('2023-12-15', 120.00, 'DINHEIRO', 2, NULL, NULL),
('2023-12-10', 75.00, 'CHEQUE', 3, NULL, NULL),
('2023-12-17', 30.00, 'PIX', 1, 1, 1),
('2023-12-16', 80.00, 'DINHEIRO', 2, 2, 2),
('2023-12-11', 150.00, 'CHEQUE', 3, 3, 3),
('2023-12-12', 45.00, 'PIX', 1, NULL, NULL),
('2023-12-13', 65.00, 'DINHEIRO', 2, NULL, NULL),
('2023-12-14', 90.00, 'CHEQUE', 3, NULL, NULL),
('2023-12-09', 200.00, 'PIX', 1, 1, 1);

INSERT INTO atestado (idAtestado, dataAtestado, nomeMedico)
VALUES
(1,'2023-12-18', 'Dr. Silva'),
(2,'2023-12-17', 'Dra. Santos'),
(3,'2023-12-16', 'Dr. Souza'),
(4,'2023-12-15', 'Dra. Costa'),
(5,'2023-12-14', 'Dr. Oliveira'),
(6,'2023-12-13', 'Dra. Pereira'),
(7,'2023-12-12', 'Dr. Almeida'),
(8,'2023-12-11', 'Dra. Campos'),
(9,'2023-12-10', 'Dr. Dias'),
(10,'2023-12-09', 'Dra. Ferreira');

INSERT INTO tem (idPaciente, idPlanosaude) VALUES 
(1, 1), 
(2, 2), 
(3, 3), 
(4, 4), 
(5, 5), 
(6, 1), 
(7, 2), 
(8, 3), 
(9, 4), 
(10, 5);

INSERT INTO detem (idEspecialidade, idProfessor) VALUES 
(1, 1), 
(2, 2), 
(3, 3), 
(4, 4), 
(5, 5), 
(1, 6), 
(2, 7), 
(3, 8), 
(4, 9), 
(5, 10);

INSERT INTO apresenta (idProfessor, idEstagiario, idSecretario, idAtestado)
VALUES
(1, 2, 3, 1),
(2, 3, 1, 2),
(3, 1, 2, 3),
(1, 4, 3, 4),
(2, 1, 1, 5),
(3, 2, 2, 6),
(1, 3, 3, 7),
(2, 4, 1, 8),
(3, 1, 2, 9),
(1, 2, 3, 10);

INSERT INTO bate (idProfessor, idEstagiario, idSecretario, idPonto) VALUES
(1, 2, 3, 1), 
(4, NULL, 5, 2), 
(3, 6, NULL, 3), 
(2, NULL, 7, 4), 
(5, 8, 3, 1), 
(1, 2, 5, 5), 
(6, NULL, 7, 2), 
(4, 9, NULL, 3), 
(3, 6, 3, 1), 
(2, NULL, 5, 4);

INSERT INTO paga (idGestor, idSalario) VALUES
(1, 2), 
(2, 4), 
(3, 1), 
(1, 6), 
(2, 3), 
(4, 2), 
(5, 5), 
(3, 7), 
(6, 4), 
(7, 1);

INSERT INTO possui (idAluno, idPaciente, idDependente)
VALUES
(1, NULL, 3),
(2, NULL, 5),
(NULL, 4, 7),
(NULL, 5, 1),
(NULL, 6, 8),
(6, NULL, 2),
(7, NULL, 4),
(NULL, 8, 6),
(NULL, 9, 10),
(NULL, 1, 9);

INSERT INTO dispoe (idModalidade, idAula) VALUES
(1, 1), 
(2, 2), 
(3, 3), 
(1, 4), 
(4, 5), 
(2, 1), 
(5, 2), 
(3, 4), 
(2, 5), 
(1, 3);

INSERT INTO participa (idAluno, idPaciente, idAula) VALUES
(1, 3, 1), 
(2, 5, 2), 
(3, 7, 3),
(4, 9, 4), 
(5, 1, 5), 
(6, 2, 1), 
(7, 4, 2), 
(8, 6, 3), 
(9, 8, 4), 
(10, 10, 5);

INSERT INTO ministra (idProfessor, idAula) VALUES
(1, 2),
(2, 1),
(3, 3),
(4, 4),
(5, 5),
(6, 2),
(7, 1),
(8, 3),
(9, 4),
(10, 5);