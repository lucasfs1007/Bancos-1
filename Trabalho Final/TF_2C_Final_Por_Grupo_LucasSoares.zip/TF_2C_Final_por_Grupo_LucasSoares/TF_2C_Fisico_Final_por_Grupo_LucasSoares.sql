-- ---------------------------------------------------------
-- -------- < TF_2C_LucasSoares > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 14/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira, Johnny da Ponte Lopes e Leonardo Ferreira Borges
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 28 Tabelas
--         => XX Usuarios
-- 
-- Ultimas Alteracoes
--   14/12/2023 => Criacao das tabelas
--   15/12/2023 => Reajuste das tabelas com as novas modelagens
-- ---------------------------------------------------------
CREATE DATABASE IF NOT EXISTS TF_2C_LucasSoares;

USE  TF_2C_LucasSoares;

CREATE TABLE DEPENDENTE (
    idDependente INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    parentesco VARCHAR(20) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(11,0) NOT NULL,
    
    CONSTRAINT DEPENDENTE_PK PRIMARY KEY (idDependente)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ALUNO (
    idAluno INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    frequencia INT NOT NULL,
    status ENUM('ATIVO', 'INATIVO') NOT NULL,
    necessidadesEspeciais VARCHAR(100) NOT NULL,
    motivo VARCHAR(500) NOT NULL,
    taxaMatricula DECIMAL(3,2) NOT NULL,
    matriculaCliente INT NOT NULL,
    dtInicio DATE NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(8,0),
    disponibilidade VARCHAR(200) NOT NULL,
    
    CONSTRAINT ALUNO_PK PRIMARY KEY (idAluno)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PACIENTE (
    idPaciente INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE  NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    laudo VARCHAR(500) NOT NULL,
    numeroCarteirinha INT NOT NULL,
    frequencia INT NOT NULL,
    status ENUM('ATIVO', 'INATIVO') NOT NULL,
    necessidadesEspeciais VARCHAR(100) NOT NULL,
    motivo VARCHAR(500) NOT NULL,
    taxaMatricula DECIMAL(3,2) NOT NULL,
    matriculaCliente INT NOT NULL,
    dtInicio DATE NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(8,0) NOT NULL,
    disponibilidade VARCHAR(200) NOT NULL,
    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE LAUDO_MEDICO (
    idLaudo INT NOT NULL AUTO_INCREMENT,
    nomeMedico VARCHAR(100) NOT NULL,
    nomeLaudo VARCHAR(100) NOT NULL,
    enfermidade VARCHAR(500) NOT NULL,
    dataEmissao DATE NOT NULL,
    numeroCrm DECIMAL(8,0) NOT NULL,
    ufCrm CHAR(2) NOT NULL,
    idPaciente INT NOT NULL,
    
    CONSTRAINT LAUDO_MEDICO_PACIENTE_FK FOREIGN KEY (idPaciente) REFERENCES PACIENTE (idPaciente) ON DELETE RESTRICT,
    CONSTRAINT LAUDO_MEDICO_PK PRIMARY KEY (idlaudo)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PLANO_SAUDE (
    idPlanosaude INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    guia VARCHAR(500) NOT NULL,
    reembolso DECIMAL(3,2) NOT NULL,
    numeroCarteirinha DECIMAL(20,0) NOT NULL,
    CONSTRAINT PLANO_SAUDE_PK PRIMARY KEY (idPlanosaude)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROFESSOR (
    idProfessor INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    matriculaProfessor INT NOT NULL,
    numeroConselho DECIMAL(8,0) NOT NULL,
    ufConselho CHAR(2) NOT NULL,
    dtAdmissao DATE NOT NULL,
    responsabilidade VARCHAR(100) NOT NULL,
    escolaridade VARCHAR(100) NOT NULL,
    cargaHoraria INT NOT NULL,
    cursos VARCHAR(500) NOT NULL,
    funcao VARCHAR(10) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(8,0) NOT NULL,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY (idProfessor)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ESTAGIARIO (
    idEstagiario INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    vinculo VARCHAR(500) NOT NULL,
    status ENUM('ATIVO', 'INATIVO') NOT NULL,
    periodo INT(2) NOT NULL,
    formacao VARCHAR(50) NOT NULL,
    dtAdmissao DATE NOT NULL,
    responsabilidade VARCHAR(100) NOT NULL,
    escolaridade VARCHAR(100) NOT NULL,
    cargaHoraria INT NOT NULL,
    cursos VARCHAR(500) NOT NULL,
    funcao VARCHAR(10) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(8,0) NOT NULL,
    idProfessor INT NOT NULL,
    
    CONSTRAINT ESTAGIARIO_PK PRIMARY KEY (idEstagiario),
    
    CONSTRAINT FK_ESTAGIARIO_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE CASCADE
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE GESTOR (
    idGestor INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    pagamentoFuncionario DECIMAL(4,3) NOT NULL,
    reciboTransacoes VARCHAR(500) NOT NULL,
    eventos VARCHAR(100) NOT NULL,
    caixa DECIMAL(4,3) NOT NULL,
    gastosVariaveis DECIMAL(4,3) NOT NULL,
    gastosFixos DECIMAL(4,3) NOT NULL,
    bonificacoes DECIMAL(4,3) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    numero INT(3) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep DECIMAL(8,0) NOT NULL,
    
    CONSTRAINT GESTOR_PK PRIMARY KEY (idGestor)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE SECRETARIO (
    idSecretario INT NOT NULL AUTO_INCREMENT,
    dtAdmissao DATE NOT NULL,
    responsabilidade VARCHAR(100) NOT NULL,
    escolaridade VARCHAR(100) NOT NULL,
    cargaHoraria INT NOT NULL,
    cursos VARCHAR(500) NOT NULL,
    funcao VARCHAR(10) NOT NULL,
    cep DECIMAL(8,0) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    numero INT(3) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    telefone DECIMAL(11,0) NOT NULL,
    cpf DECIMAL(11,0) NOT NULL,
    email VARCHAR(255) NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT SECRETARIO_PK PRIMARY KEY (idSecretario)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE AULA (
    idAula INT NOT NULL AUTO_INCREMENT,
    horaInicio TIME NOT NULL,
    horaFim TIME NOT NULL,
    frequencia INT NOT NULL,
    idEstagiario INT,
    
    CONSTRAINT AULA_PK PRIMARY KEY (idAula),
    
    CONSTRAINT FK_AULA_2
    FOREIGN KEY (idEstagiario)
    REFERENCES ESTAGIARIO (idEstagiario)
    ON DELETE CASCADE
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ESPECIALIDADE (
    idEspecialidade INT NOT NULL AUTO_INCREMENT,
    nomeEspecilaidade VARCHAR(100) NOT NULL,
    
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (idEspecialidade)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE MODALIDADE (
    idModalidade INT NOT NULL AUTO_INCREMENT,
    nomeModalidade VARCHAR(100) NOT NULL,
    descricao VARCHAR(500) NOT NULL,
    tipoModalidade VARCHAR(100) NOT NULL,
    
    CONSTRAINT MODALIDADE_PK PRIMARY KEY (idModalidade)
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONTRATO (
    idContrato INT NOT NULL AUTO_INCREMENT,
    taxaMatricula DECIMAL(3,2) NOT NULL,
    valor DECIMAL(4,3) NOT NULL,
    tipoContrato ENUM('ADESÃO', 'CONTRATAÇÃO') NOT NULL,
    idSecretarioElabora INT NOT NULL,
    idProfessor INT,
    idEstagiario INT,
    idSecretario INT,
    idAluno INT,
    idPaciente INT,
    
    CONSTRAINT CONTRATO_PK PRIMARY KEY (idContrato),
    
    CONSTRAINT FK_CONTRATO_2
    FOREIGN KEY (idSecretarioElabora)
    REFERENCES SECRETARIO (idSecretario)
    ON DELETE CASCADE,
 
    
    CONSTRAINT FK_CONTRATO_3
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT,
    
    CONSTRAINT FK_CONTRATO_4
    FOREIGN KEY (idEstagiario)
    REFERENCES ESTAGIARIO (idEstagiario)
    ON DELETE RESTRICT,
    
    CONSTRAINT FK_CONTRATO_5
    FOREIGN KEY (idAluno)
    REFERENCES ALUNO (idAluno)
    ON DELETE RESTRICT,
    
    CONSTRAINT FK_CONTRATO_6
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
    ON DELETE RESTRICT
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE SALARIO (
    idSalario INT NOT NULL AUTO_INCREMENT,
    dataPagamento DATE NOT NULL,
    valor DECIMAL(4,2) NOT NULL,
    idProfessor INT,
    idEstagiario INT,
    idSecretario INT,
    
    CONSTRAINT SALARIO_PK PRIMARY KEY (idSalario),
    
    CONSTRAINT FK_SALARIO_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT,
    
	CONSTRAINT FK_SALARIO_3
    FOREIGN KEY (idEstagiario)
    REFERENCES ESTAGIARIO (idEstagiario)
    ON DELETE RESTRICT,
	
    CONSTRAINT FK_SALARIO_4
    FOREIGN KEY (idSecretario)
    REFERENCES SECRETARIO (idSecretario)
    ON DELETE RESTRICT
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PONTO (
    idPonto INT NOT NULL AUTO_INCREMENT,
    horaSaida TIME NOT NULL,
    horaEntrada TIME NOT NULL,
    idSalario INT NOT NULL,
    
    CONSTRAINT PONTO_PK PRIMARY KEY (idPonto),
    
    CONSTRAINT FK_PONTO_2
    FOREIGN KEY (idSalario)
    REFERENCES SALARIO (idSalario)
    ON DELETE RESTRICT
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE RELATORIO_ALUNO (
    idRelatorioAluno INT NOT NULL AUTO_INCREMENT,
    recomendacao VARCHAR(500) NOT NULL,
    avaliacao VARCHAR(500) NOT NULL,
    progresso VARCHAR(500) NOT NULL,
    assinatura VARCHAR(100) NOT NULL,
    objetivo VARCHAR(500) NOT NULL,
    dataRelatorio DATE NOT NULL,
    idProfessor INT NOT NULL,
    idAluno INT NOT NULL,
    
    CONSTRAINT RELATORIO_ALUNO_PK PRIMARY KEY (idRelatorioAluno),
    
    CONSTRAINT FK_RELATORIO_ALUNO_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE CASCADE,
	
    CONSTRAINT FK_RELATORIO_ALUNO_3
    FOREIGN KEY (idAluno)
    REFERENCES ALUNO (idAluno)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE RELATORIO_PACIENTE (
    idRelatorioPaciente INT NOT NULL AUTO_INCREMENT,
    trauma VARCHAR(200) NOT NULL,
    historicoMedico VARCHAR(500) NOT NULL,
    recomendacaoMedica VARCHAR(500) NOT NULL,
    tratamento VARCHAR(200) NOT NULL,
    avaliacao VARCHAR(500) NOT NULL,
    progresso VARCHAR(500) NOT NULL,
    assinatura VARCHAR(100) NOT NULL,
    objetivo VARCHAR(500) NOT NULL,
    dataRelatorio DATE NOT NULL,
    idProfessor INT NOT NULL,
    idPaciente INT NOT NULL,
    
    CONSTRAINT RELATORIO_PACIENTE_PK PRIMARY KEY (idRelatorioPaciente),
    
    CONSTRAINT FK_RELATORIO_PACIENTE_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE CASCADE,
	
    CONSTRAINT FK_RELATORIO_PACIENTE_3
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PAGAMENTO (
    idPagamento INT NOT NULL AUTO_INCREMENT,
    dataPagamento DATE NOT NULL,
    valor DECIMAL(4,2) NOT NULL,
    formaPagamento ENUM('PIX', 'CHEQUE', 'DINHEIRO') NOT NULL,
    idAluno INT,
    idPaciente INT,
    idPlanosaude INT,
    
    CONSTRAINT PAGAMENTO_PK PRIMARY KEY (idPagamento),
    
    CONSTRAINT FK_PAGAMENTO_2
    FOREIGN KEY (idAluno)
    REFERENCES ALUNO (idAluno)
    ON DELETE CASCADE,
    
    CONSTRAINT FK_PAGAMENTO_3
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
    ON DELETE CASCADE,
	
    CONSTRAINT FK_PAGAMENTO_4
    FOREIGN KEY (idPlanosaude)
    REFERENCES PLANO_SAUDE (idPlanosaude)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ATESTADO (
    idAtestado INT NOT NULL AUTO_INCREMENT,
    dataAtestado DATE NOT NULL,
    nomeMedico VARCHAR(100) NOT NULL,
    
    CONSTRAINT ATESTADO_PK PRIMARY KEY (idAtestado)
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE tem (
    idPaciente INT NOT NULL,
    idPlanosaude INT NOT NULL,
    CONSTRAINT FK_tem_1
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
    ON DELETE RESTRICT,
	
    CONSTRAINT FK_tem_2
    FOREIGN KEY (idPlanosaude)
    REFERENCES PLANO_SAUDE (idPlanosaude)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE detem (
    idEspecialidade INT NOT NULL,
    idProfessor INT NOT NULL,
    CONSTRAINT FK_detem_1
    FOREIGN KEY (idEspecialidade)
    REFERENCES ESPECIALIDADE (idEspecialidade)
    ON DELETE RESTRICT,
    
    CONSTRAINT FK_detem_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE apresenta (
    idProfessor INT,
    idEstagiario INT,
    idSecretario INT,
    idAtestado INT NOT NULL,
    
    CONSTRAINT FK_apresenta_1
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_apresenta_2
    FOREIGN KEY (idEstagiario)
    REFERENCES ESTAGIARIO (idEstagiario)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_apresenta_3
    FOREIGN KEY (idSecretario)
    REFERENCES SECRETARIO (idSecretario)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_apresenta_4
    FOREIGN KEY (idAtestado)
    REFERENCES ATESTADO (idAtestado)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE bate (
    idProfessor INT,
    idEstagiario INT,
    idSecretario INT,
    idPonto INT NOT NULL,
    
    CONSTRAINT FK_bate_1
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT,
	
    CONSTRAINT FK_bate_2
    FOREIGN KEY (idEstagiario)
    REFERENCES ESTAGIARIO (idEstagiario)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_bate_3
    FOREIGN KEY (idSecretario)
    REFERENCES SECRETARIO (idSecretario)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_bate_4
    FOREIGN KEY (idPonto)
    REFERENCES PONTO (idPonto)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE paga (
    idGestor INT NOT NULL,
    idSalario INT NOT NULL,
    
    CONSTRAINT FK_paga_1
    FOREIGN KEY (idGestor)
    REFERENCES GESTOR (idGestor)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_paga_2
    FOREIGN KEY (idSalario)
    REFERENCES SALARIO (idSalario)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE possui (
    idAluno INT,
    idPaciente INT,
    idDependente INT NOT NULL,
    
    CONSTRAINT FK_possui_1
    FOREIGN KEY (idAluno)
    REFERENCES ALUNO (idAluno)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_possui_2
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_possui_3
    FOREIGN KEY (idDependente)
    REFERENCES DEPENDENTE (idDependente)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE dispoe (
    idModalidade INT NOT NULL,
    idAula INT NOT NULL,
    
    CONSTRAINT FK_dispoe_1
    FOREIGN KEY (idModalidade)
    REFERENCES MODALIDADE (idModalidade)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_dispoe_2
    FOREIGN KEY (idAula)
    REFERENCES AULA (idAula)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE participa (
    idAluno INT,
    idPaciente INT,
    idAula INT NOT NULL,
    
    CONSTRAINT FK_participa_1
    FOREIGN KEY (idAluno)
    REFERENCES ALUNO (idAluno)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_participa_2
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente)
    ON DELETE RESTRICT,
	
    CONSTRAINT FK_participa_3
    FOREIGN KEY (idAula)
    REFERENCES AULA (idAula)
    ON DELETE RESTRICT
)ENGINE = InnoDB;

CREATE TABLE ministra (
    idProfessor INT NOT NULL,
    idAula INT NOT NULL,
    
    CONSTRAINT FK_ministra_1
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT,
 
	CONSTRAINT FK_ministra_2
    FOREIGN KEY (idAula)
    REFERENCES AULA (idAula)
    ON DELETE RESTRICT
)ENGINE = InnoDB;
 


 
 

 
 

 

 

 
