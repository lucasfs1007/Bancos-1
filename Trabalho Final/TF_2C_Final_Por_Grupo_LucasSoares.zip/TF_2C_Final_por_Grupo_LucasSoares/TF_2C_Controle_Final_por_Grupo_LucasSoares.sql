-- --------  << TF_2C_LucasSoares >>  ----------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 16/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira, Johnny da Ponte Lopes e Leonardo Ferreira Borges
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 22 TABELAS
--         => 03 USUÁRIOS

--  14/12/2023 => sAdiciona a criação dos dois perfis de usuário
-- 17/12/2023 => Revisando os usuários e adicionando a administração
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_2C_LucasSoares;

-- Criação dos usuários
CREATE USER 'gestor'@'localhost' IDENTIFIED BY 'gestor123';
CREATE USER 'funcionario'@'localhost' IDENTIFIED BY 'func123';
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin123';

-- Criação dos papéis
CREATE ROLE gestor;
CREATE ROLE funcionario;
CREATE ROLE administrador;

GRANT gestor TO 'gestor'@'localhost';
GRANT funcionario TO 'funcionario'@'localhost';
GRANT administrador TO 'admin'@'localhost';

-- Gestor
GRANT ALL PRIVILEGES ON TF_2C_LucasSoares.* TO gestor; -- Dando todos os privilegios a senhora cris

-- Atribuição de privilégios para o papel 'funcionario' 
GRANT INSERT ON TF_2C_LucasSoares.ALUNO TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.PACIENTE TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.MODALIDADE TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.ESPECIALIDADE TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.AULA TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.RELATORIO_ALUNO TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.RELATORIO_PACIENTE TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.LAUDO_MEDICO TO funcionario;
GRANT INSERT ON TF_2C_LucasSoares.PONTO TO funcionario;

-- Adminstração
GRANT INSERT ON TF_2C_LucasSoares.CONTRATO TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.ATESTADO TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.ESTAGIARIO TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.PROFESSOR TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.PLANO_SAUDE TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.DEPENDENTE TO administrador;
-- As tabelas de relacionamento vieram pra ca
GRANT INSERT ON TF_2C_LucasSoares.tem TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.detem TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.apresenta TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.bate TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.paga TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.possui TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.dispoe TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.participa TO administrador;
GRANT INSERT ON TF_2C_LucasSoares.ministra TO administrador;