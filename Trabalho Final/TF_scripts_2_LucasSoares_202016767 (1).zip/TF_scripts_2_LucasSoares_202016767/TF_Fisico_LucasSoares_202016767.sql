-- ---------------------------------------------------------
-- -------- < TF_2C1_LucasSoares > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 02/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 25 Tabelas
--         => 02 Usuarios
-- 
-- Ultimas Alteracoes
--   02/12/2023 => Criacao das tabelas
-- ---------------------------------------------------------
CREATE DATABASE IF NOT EXISTS TF_2C1_LucasSoares;

USE TF_2C1_LucasSoares;

CREATE TABLE PESSOA (
    cpf VARCHAR(15) PRIMARY KEY NOT NULL, 
    nomeCompleto VARCHAR(100) NOT NULL,
    rg VARCHAR(20) NOT NULL,
    cep VARCHAR(10) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL, 
    telefone VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL,
	CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
)Engine=InnoDB;

CREATE TABLE CLIENTE (
    matricula INT PRIMARY KEY NOT NULL,
    taxaMatricula DECIMAL(3, 2) NOT NULL,
    motivo VARCHAR(100) NOT NULL,
    necessidadesEspeciais VARCHAR(100)NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    status VARCHAR(100)NOT NULL,
    dtInicio DATE NOT NULL,
    frequencia INT NOT NULL,
    idRelatorio INT NOT NULL,
    CONSTRAINT CLIENTE_PK PRIMARY KEY (matricula),
    FOREIGN KEY (idRelatorio) REFERENCES RELATORIO(idRelatorio),
    FOREIGN KEY (cpf) REFERENCES PESSOA(cpf)
)Engine=InnODB;

CREATE TABLE ALUNO (
    idAluno INT PRIMARY KEY NOT NULL,
    idContratoAluno INT NOT NULL,
	CONSTRAINT ALUNO_PK PRIMARY KEY (idAluno),
    FOREIGN KEY (idContratoAluno) REFERENCES CONTRATO(idContratoAluno), 
    FOREIGN KEY (cpf) REFERENCES PESSOA(cpf)
)Engine=InnoDB;

CREATE TABLE PACIENTE (
    idPaciente INT PRIMARY KEY NOT NULL,
    idContratoPaciente INT NOT NULL,
    numeroCarteirinha INT NOT NULL,
    laudo VARCHAR(500) NOT NULL,
    trauma VARCHAR(100) NOT NULL,
    idLaudo INT NOT NULL,
    CONSTRAINT PACIENTE_PK PRIMARY KEY(idPaciente),
    FOREIGN KEY (idPaciente) REFERENCES PESSOA(cpf),
    FOREIGN KEY (idContratoPaciente) REFERENCES CONTRATO_PACIENTE(idContratoPaciente),
    FOREIGN KEY (idLaudo) REFERENCES LAUDO_MEDICO(idLaudo)
)Engine = InnoDB;

CREATE TABLE FUNCIONARIO (
    matricula INT PRIMARY KEY NOT NULL,
    dtAdmissao DATE NOT NULL,
    salario DECIMAL(4,3) NOT NULL,
    cursos VARCHAR(100) NOT NULL,
    cargaHoraria INT NOT NULL,
    escolaridade VARCHAR(100) NOT NULL,
    funcao VARCHAR(100) NOT NULL,
    responsabilidade VARCHAR(100) NOT NULL,
    CONSTRAINT FUNCIONARIO_PK PRIMARY KEY(matricula),
    FOREIGN KEY (matricula) REFERENCES PESSOA(cpf)
)Engine = InnoDB;

CREATE TABLE PROFESSOR (
    matriculaProfessor INT PRIMARY KEY NOT NULL,
    idAula INT NOT NULL,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY(matriculaProfessor),
    FOREIGN KEY (matriculaProfessor) REFERENCES FUNCIONARIO(matricula),
    FOREIGN KEY (idAula) REFERENCES AULA(idAula)
)Engine = InnoDB;

CREATE TABLE EDUCADOR_FISICO (
    cref VARCHAR(11) PRIMARY KEY NOT NULL, -- 6 Digitos + hifem + letra + barra + sigla de estado
    idModalidade INT NOT NULL,
    CONSTRAINT EDUCADOR_FISICO_PK PRIMARY KEY(cref),
    FOREIGN KEY (cref) REFERENCES PROFESSOR(matriculaProfessor),
    FOREIGN KEY (idModalidade) REFERENCES MODALIDADE(idModalidade)
)Engine = InnoDB;

CREATE TABLE FISIOTERAPEUTA (
    crefito int(4) PRIMARY KEY NOT NULL, 
    idModalidade INT NOT NULL,
    CONSTRAINT FISIOTERAPUETA_PK PRIMARY KEY(crefito),
    FOREIGN KEY (cref) REFERENCES PROFESSOR(matriculaProfessor),
    FOREIGN KEY (idModalidade) REFERENCES MODALIDADE(idModalidade)
)Engine = InnoDB;

CREATE TABLE ADMINISTRACAO (
    matriculaAdmin INT PRIMARY KEY NOT NULL,
    cursoAdministrativo VARCHAR(100) NOT NULL,
    CONSTRAINT ADMINISTRACAO_PK PRIMARY KEY(matriculaAdmin),
    FOREIGN KEY (matriculaAdmin) REFERENCES FUNCIONARIO(matricula)
)Engine = InnoDb;

CREATE TABLE FINANCEIRO (
    idFinanceiro INT PRIMARY KEY NOT NULL,
    reciboTransacoes INT NOT NULL,
    caixa DECIMAL(4,3) NOT NULL,
    gastosFixos DECIMAL(4,3) NOT NULL,
    gastosVariaveis DECIMAL(4,3) NOT NULL,
    pagamentoFuncionario DECIMAL(4,3) NOT NULL,
    eventos VARCHAR(100) NOT NULL,  -- Fiquei na duvida do que era deixei um Varchar aqui
    bonificacoes DECIMAL(4,3) NOT NULL,
    pagamentoAluno DECIMAL(3,2) NOT NULL,
    CONSTRAINT FINANCEIRO_PK PRIMARY KEY(idFinanceiro),
    FOREIGN KEY (idFinanceiro) REFERENCES ADMINISTRACAO(matriculaAdmin)
)Engine = InnoDB;

CREATE TABLE SECRETARIO (
    idSecretario INT PRIMARY KEY NOT NULL,
    idContrato INT NOT NULL,
    idAluno INT NOT NULL,
    CONSTRAINT SECRETARIO_PK PRIMARY KEY(idSecretario),
    FOREIGN KEY (idSecretario) REFERENCES ADMINISTRACAO(matriculaAdmin),
    FOREIGN KEY (idContrato) REFERENCES CONTRATO(idContrato),
    FOREIGN KEY (idAluno) REFERENCES ALUNO(idAluno)
)Engine = InnoDB;


CREATE TABLE ESTAGIARIO (
    idEstagiario INT PRIMARY KEY NOT NULL,
    orientador VARCHAR(100) NOT NULL, -- Ideia é guardar o nome dele mesmo né ?
    vinculo VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    CONSTRAINT ESTAGIARIO_PK PRIMARY KEY(idEstagiario),
    FOREIGN KEY (idEstagiario) REFERENCES FUNCIONARIO(matricula),
    FOREIGN KEY (orientador) REFERENCES FISIOTERAPEUTA(crefito)
)Engine = InnoDB;

CREATE TABLE PLANO_SAUDE (
    numeroCarteirinha INT(9) PRIMARY KEY NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    guia VARCHAR(100) NOT NULL,
    reembolso DECIMAL(3,2) NOT NULL,
    CONSTRAINT PLANO_SAUDE_PK PRIMARY KEY(numeroCarteirinha)
)Engine = InnoDb;

CREATE TABLE MODALIDADE (
    idModalidade INT PRIMARY KEY NOT NULL,
    nomeModalidade VARCHAR(100) NOT NULL,
    tipoModalidade VARCHAR(100) NOT NULL,
    descricao TEXT(500),
    CONSTRAINT MODALIDADE_PK PRIMARY KEY(idModalidade)
)Engine = InnoDB;

CREATE TABLE AULA (
    idAula INT PRIMARY KEY NOT NULL,
    horaInicio TIME NOT NULL,
    horaFim TIME NOT NULL,
    frequencia ENUM('P','F') NOT NULL, -- A ideia é preencher P para presente e F para faltar
    idAluno INT NOT NULL,
    crefito INT(4) NOT NULL,
	cref VARCHAR(11) NOT NULL,
    idRelatorio INT NOT NULL,
    CONSTRAINT AULA_PK PRIMARY KEY (idAula),
    FOREIGN KEY (idAluno) REFERENCES ALUNO(idAluno),
    FOREIGN KEY (crefito) REFERENCES FISIOTERAPEUTA(crefito),
    FOREIGN KEY (cref) REFERENCES EDUCADOR_FISICO(cref),
    FOREIGN KEY (idRelatorio) REFERENCES RELATORIO(idRelatorio)
)Engine = InnoDB;

CREATE TABLE RELATORIO (
    idRelatorio INT PRIMARY KEY NOT NULL,
    idAula INT NOT NULL,
    crefito INT(4) NOT NULL,
    matricula INT NOT NULL,
    avaliacao VARCHAR(100) NOT NULL,
    objetivo TEXT(500) NOT NULL,
    progresso TEXT(500) NOT NULL,
	dataRelatorio DATE NOT NULL,
    assinatura VARCHAR(100) NOT NULL,
    CONSTRAINT RELATORIO_PK PRIMARY KEY(idRelatorio),
    FOREIGN KEY (idAula) REFERENCES AULA(idAula),
    FOREIGN KEY (crefito) REFERENCES FISIOTERAPEUTA(crefito),
    FOREIGN KEY (matricula) REFERENCES PESSOA(cpf)
)Engine = InnoDB;

CREATE TABLE RELATORIO_ALUNO (
    idRelatorioAluno INT PRIMARY KEY NOT NULL,
    idAluno INT NOT NULL,
    recomendacao TEXT(500) NOT NULL,
    CONSTRAINT RELATORIO_ALUNO_PK PRIMARY KEY(idRelatorioAluno),
    FOREIGN KEY (idRelatorioAluno) REFERENCES RELATORIO(idRelatorio),
    FOREIGN KEY (idAluno) REFERENCES ALUNO(idAluno)
)Engine = InnoDB;

CREATE TABLE RELATORIO_PACIENTE (
    idRelatorioPaciente INT PRIMARY KEY NOT NULL,
    idPaciente INT NOT NULL,
    numeroCarteirinha INT NOT NULL,
    laudo VARCHAR(500) NOT NULL,
    trauma VARCHAR(100) NOT NULL,
    tratamento TEXT(500) NOT NULL,
    historicoMedico TEXT(500) NOT NULL,
    recomendacaoMedica TEXT(500) NOT NULL,
    CONSTRAINT RELATORIO_PACIENTE_PK PRIMARY KEY(idRelatorioPaciente),
    FOREIGN KEY (idRelatorioPaciente) REFERENCES RELATORIO(idRelatorio),
    FOREIGN KEY (idPaciente) REFERENCES PACIENTE(idPaciente)
)Engine = InnoDB;

CREATE TABLE LAUDO_MEDICO (
    idLaudo INT PRIMARY KEY NOT NULL,
    nomeLaudo VARCHAR(100) NOT NULL,
    dataEmissao DATE NOT NULL,
    nomeMedico VARCHAR(100) NOT NULL,
    numeroCrm INT(6) NOT NULL,
    estado CHAR(2) NOT NULL,
    CONSTRAINT LAUDO_MEDICO_PK PRIMARY KEY (idLaudo)
)Engine = InnoDB;

CREATE TABLE CONTRATO (
    idContrato INT PRIMARY KEY NOT NULL,
    idAluno INT NOT NULL,
    idAula INT NOT NULL,
    matricula INT NOT NULL,
    taxaMatricula DECIMAL(3,2) NOT NULL,
    valor DECIMAL(3,2),
    CONSTRAINT CONTRATO_PK PRIMARY KEY(idContrato),
    FOREIGN KEY (idAluno) REFERENCES ALUNO(idAluno),
    FOREIGN KEY (idAula) REFERENCES AULA(idAula),
    FOREIGN KEY (matricula) REFERENCES PESSOA(cpf)
)Engine=InnoDb;

CREATE TABLE CONTRATO_PACIENTE (
    idContratoPaciente INT PRIMARY KEY NOT NULL,
    idPaciente INT NOT NULL,
    reembolso DECIMAL(3,2) NOT NULL,
    CONSTRAINT CONTRATO_PACIENTE_PK PRIMARY KEY (idContratoPaciente),
    FOREIGN KEY (idPaciente) REFERENCES PACIENTE(idPaciente)
)Engine=InnoDb;

CREATE TABLE PONTO (
    idPonto INT PRIMARY KEY NOT NULL,
    matricula INT NOT NULL,
    horaEntrada TIME NOT NULL,
    horaSaida TIME NOT NULL,
    CONSTRAINT PONTO_PK PRIMARY KEY(idPonto),
    FOREIGN KEY (matricula) REFERENCES FUNCIONARIO(matricula)
)Engine = InnoDB;

CREATE TABLE SALARIO (
    idSalario INT PRIMARY KEY NOT NULL,
    idPonto INT NOT NULL,
    matricula INT NOT NULL,
	dataPagamento DATE NOT NULL,
    CONSTRAINT SALARIO_PK PRIMARY KEY(idSalario),
    FOREIGN KEY (idPonto) REFERENCES PONTO(idPonto),
    FOREIGN KEY (matricula) REFERENCES FUNCIONARIO(matricula)
)Engine = InnoDB;

CREATE TABLE PAGAMENTO (
    idPagamento INT PRIMARY KEY NOT NULL,
    idContrato INT NOT NULL,
    dataEmissao DATE NOT NULL,
    desconto DECIMAL(3,2) NOT NULL,
    recibo INT NOT NULL,
    CONSTRAINT PAGAMENTO_PK PRIMARY KEY (idPagamento),
    FOREIGN KEY (idContrato) REFERENCES CONTRATO(idContrato)
)Engine = InnoDB;

