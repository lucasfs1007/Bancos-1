-- ---------------------------------------------------------
-- -------- < TF_2C1_LucasSoares > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 02/12/2023
-- Autor(es) ..............: Lucas Felipe Soares, Maria Eduarda Dos Santos Abritta Ferreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2C1_LucasSoares
--
-- PROJETO => 01 Base de Dados
--         => 25 Tabelas
--         => 02 Usuarios
-- 
-- Ultimas Alteracoes
--   02/12/2023 => Criacao do Script de deleção
-- ---------------------------------------------------------
USE TF_2C1_LucasSoares;

DROP TABLE PAGAMENTO;
DROP TABLE SALARIO;
DROP TABLE PONTO;
DROP TABLE CONTRATO_PACIENTE;
DROP TABLE LAUDO_MEDICO;
DROP TABLE RELATORIO_PACIENTE;
DROP TABLE RELATORIO_ALUNO;
DROP TABLE RELATORIO;
DROP TABLE AULA;
DROP TABLE MODALIDADE;
DROP TABLE PLANO_SAUDE;
DROP TABLE ESTAGIARIO;
DROP TABLE SECRETARIO;
DROP TABLE FINANCEIRO;
DROP TABLE ADMINISTRACAO;
DROP TABLE EDUCADOR_FISICO;
DROP TABLE FISIOTERAPEUTA;
DROP TABLE PROFESSOR;
DROP TABLE FUNCIONARIO;
DROP TABLE CONTRATO;
DROP TABLE CLIENTE;
DROP TABLE PACIENTE;
DROP TABLE ALUNO;
DROP TABLE PESSOA;