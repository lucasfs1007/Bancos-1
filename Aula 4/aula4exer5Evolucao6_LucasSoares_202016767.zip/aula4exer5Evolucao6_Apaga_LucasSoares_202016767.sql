-- -------- <aula4exer5Evolucao6 > --------
--
--            SCRIPT DE Remocao
--
-- Data Criacao ...........: 30/10/2023
-- Autor(es) ..............: Lucas Felipe Sores
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- Ultimas Alteracoes
--   05/11/2023 => Remocao de tabelas.
--
-- ---------------------------------------------------------

use aula4exer5Evolucao6;

DROP TABLE IF EXISTS contem;
DROP TABLE IF EXISTS MEDICAMENTO;
DROP TABLE IF EXISTS RECEITA;
DROP TABLE IF EXISTS CONSULTA;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS PACIENTE;
DROP TABLE IF EXISTS possui;
DROP TABLE IF EXISTS ESPECIALIzacao;
DROP TABLE IF EXISTS MEDICO;

