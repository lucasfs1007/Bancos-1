-- -------- <aula4exer5Evolucao6 > --------
--
--            SCRIPT DE Populacao
--
-- Data Criacao ...........: 30/10/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- Ultimas Alteracoes
-- 		05/11/2023 => Populacao de tabelas.
--
-- ---------------------------------------------------------
use aula4exer5Evolucao6;

INSERT INTO MEDICO (numeroCrm,unidadeFederativa, nomeCompletoMedico) VALUES
(1, 'RJ', 'Dr. João da Silva'),
(2, 'SP', 'Dra. Maria Souza'),
(3, 'MG', 'Dr. Carlos Santos');

INSERT INTO PACIENTE (idPaciente,nomeCompletoPaciente, dataNascimento, numero, logradouro, bairro, cidade, UF, CEP, complemento, sexo) VALUES
('1','Ana Pereira', '1990-05-15', 1, 'Rua A', 'Centro', 'Rio de Janeiro', 'RJ', 20000000, 'Apt 101', 'F'),
('2','Luiz Santos', '1985-12-10', 2, 'Av. B', 'Belavista', 'São Paulo', 'SP', 10000000, 'Casa', 'M'),
('3','Marcia Oliveira', '2000-03-25', 3, 'Rua C', 'Bairro Novo', 'Belo Horizonte', 'MG', 30000000, 'Apt 202', 'F');

INSERT INTO CONSULTA (dataConsulta, numero, unidadeFederativa, nomeCompletoPaciente, dataNascimento, horaConsulta)VALUES
('2023-10-15', 1, 'RJ', 'Ana Pereira', '1990-05-15', '13:32'),
('2023-10-16 ', 2, 'SP', 'Luiz Santos', '1985-12-10','15:21'),
('2023-10-17', 3, 'MG', 'Marcia Oliveira', '2000-03-25','09:46');

INSERT INTO RECEITA (idReceita, dataConsulta,nomeMedicamento)VALUES
(1, '2023-10-15', 'Paracetamol'),
(2, '2023-10-16 ', 'Ibuprofeno'),
(3, '2023-10-17 ', 'Amoxicilina');

INSERT INTO ESPECIALIZACAO (idEspecialidade, especialidade) VALUES
(1, 'Cardiologia'),
(2, 'Dermatologia'),
(3, 'Ortopedia');

INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, principioAtivo) VALUES
(1, 'Aspirina', 'Ácido Acetilsalicílico'),
(2, 'Omeprazol', 'Omeprazol Sódico'),
(3, 'Atorvastatina', 'Atorvastatina Cálcica');

INSERT INTO telefone (idTelefone, nomeCompletoPaciente, dataNascimento, telefone) VALUES
(1, 'Ana Pereira', '1990-05-15', 5511999999999),
(2, 'Luiz Santos', '1985-12-10', 5511888888888),
(3, 'Marcia Oliveira', '2000-03-25', 5522999999999);

INSERT INTO possui (numeroCrm, unidadeFederativa, idEspecialidade) VALUES
(1, 'RJ', 1),
(2, 'SP', 2),
(3, 'MG', 3);

INSERT INTO tem (idReceita, idMedicamento) VALUES
(1, 1),
(2, 2),
(3, 3);