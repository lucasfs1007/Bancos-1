-- -------- <aula4exer5Evolucao6 > --------
--
--            SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 30/10/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- Ultimas Alteracoes
--   05/11/2023 => Criacao de nova tabela.
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer5Evolucao6;

USE aula4exer5Evolucao6;

CREATE TABLE IF NOT EXISTS MEDICO (
    numeroCrm INT(8) NOT NULL,
    unidadeFederativa CHAR(2) NOT NULL,
    nomeCompletoMedico VARCHAR(30) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (numeroCrm, unidadeFederativa)
);

CREATE TABLE IF NOT EXISTS PACIENTE (
    idPaciente INT(2) NOT NULL PRIMARY KEY, 
    nomeCompletoPaciente VARCHAR(30) NOT NULL,
    dataNascimento DATE NOT NULL,
    numero INT(2) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    bairro VARCHAR(60) NOT NULL,
    cidade VARCHAR(30) NOT NULL,
    UF CHAR(2) NOT NULL,
    CEP INT(8) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    sexo CHAR(1) NOT NULL,

    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente)
);

CREATE TABLE IF NOT EXISTS CONSULTA (
    idConsulta INT(2) NOT NULL, 
    dataConsulta DATE NOT NULL,
    numeroCrm INT(8) NOT NULL,
    unidadeFederativa CHAR(2) NOT NULL,
    idPaciente INT(2) NOT NULL, 
    horaConsulta TIMESTAMP NOT NULL,

    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente) REFERENCES PACIENTE (idPaciente),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (numeroCrm, unidadeFederativa) REFERENCES MEDICO (numeroCrm, unidadeFederativa)
);


CREATE TABLE IF NOT EXISTS RECEITA (
    idReceita INT(10) NOT NULL PRIMARY KEY,
    dataConsulta TIMESTAMP NOT NULL,
    nomeMedicamento VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS ESPECIALIZACAO (
    idEspecialidade INT(10) NOT NULL,
    especialidade VARCHAR(30) NOT NULL,

    CONSTRAINT ESPECIALIZACAO_PK PRIMARY KEY (idEspecialidade)
);

CREATE TABLE IF NOT EXISTS MEDICAMENTO (
    idMedicamento INT(10) NOT NULL,
    nomeMedicamento VARCHAR(30) NOT NULL,
    principioAtivo VARCHAR(30) NOT NULL,

    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idMedicamento)
);

CREATE TABLE IF NOT EXISTS telefone (
    idTelefone INT(10) NOT NULL,
    nomeCompletoPaciente VARCHAR(30) NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone BIGINT(14),

    CONSTRAINT telefone_PK PRIMARY KEY (idTelefone),
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (nomeCompletoPaciente, dataNascimento)
    REFERENCES PACIENTE (nomeCompletoPaciente, dataNascimento)
);

CREATE TABLE IF NOT EXISTS possui (
    numeroCrm INT(8) NOT NULL,
    unidadeFederativa CHAR(2) NOT NULL,
    idEspecialidade INT NOT NULL,

    CONSTRAINT possui_PK PRIMARY KEY (numeroCrm, unidadeFederativa, idEspecialidade),
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (numeroCrm, unidadeFederativa)
    REFERENCES MEDICO (numeroCrm, unidadeFederativa),
    CONSTRAINT possui_ESPECIALIZACAO_FK FOREIGN KEY (idEspecialidade)
    REFERENCES ESPECIALIZACAO (idEspecialidade)
);

CREATE TABLE IF NOT EXISTS tem (
    idReceita INT(10) NOT NULL,
    idMedicamento INT(10) NOT NULL,

    CONSTRAINT tem_PK PRIMARY KEY (idReceita, idMedicamento),
    CONSTRAINT tem_RECEITA_FK FOREIGN KEY (idReceita)
    REFERENCES RECEITA (idReceita),
    CONSTRAINT tem_MEDICAMENTO_FK FOREIGN KEY (idMedicamento)
    REFERENCES MEDICAMENTO (idMedicamento)
);