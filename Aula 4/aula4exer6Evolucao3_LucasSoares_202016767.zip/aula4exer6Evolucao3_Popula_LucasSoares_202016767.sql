-- -----------     <<aula4exer6Evolucao3 >>     -------------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 29/10/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6Evolucao3
-- 
-- Alteracoes evolucao 2 ..: 29/10/2023
--   => Criacao de novo Script para popular as tabelas da base de dados aula4exer6Evolucao2

-- Alteracoes evolucao 3 ..: 08/11/2023
-- --> Criacao de mais um popula e ajuste nas tabelas existentes da evolucao anterior

-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer6Evolucao3;

INSERT INTO PROPRIETARIO(cpf, nome, dataNascimento, sexo, rua, numero, bairro, complemento, cidade, estado, cep) VALUES (
	61766506151,
    'Lorenzo Davi Augusto',
    '1981-08-15',
    'M',
    'Quadra QR 106 Conjunto 11',
    '362',
    'Samambaia Sul',
    'Aprt 4 terreo',
    'Brasília',
    'DF',
    72302111
);

INSERT INTO telefone(cpf, numero) VALUES (
	61766506151,
    61996906139
);

INSERT INTO MODELO(codigoModelo, nomeModelo) VALUES (
	159654,
    'Way 1.8 Total Flex'
);

INSERT INTO CATEGORIA(codigoCategoria, nomeCategoria) VALUES (
	01,
    'Automóvel'
);

INSERT INTO VEICULO(placa, cpf, codigoCategoria, codigoModelo, chassi, anoFabricacao, corPredominante) VALUES (
	'JKD3720',
    61766506151,
    01,
    159654,
    '7AWFZwFw55VA15521',
    1985,
    'Cinza'
);

INSERT INTO LOCALIZACAO(codigoLocal, latitude, longitude, velocidadePermitida) VALUES (
	'aab343',
    30.192874,
    301.109231,
    60
);

INSERT INTO AGENTE_TRANSITO(matriculaFuncional, nomeAgente, dataContratacao) VALUES (
	402,
    'Erick Manoel Jesus',
    '2003-02-07'
);

INSERT INTO TIPOINFRACAO(codigoTipoInfracao, valorInfracao, descricao) VALUES (
	1,
    '100,00',
    'Estacionou em local proibido'
);

INSERT INTO INFRACAO(idInfracao, placa, codigoLocal, matriculaFuncional, codigoTipoInfracao, data, velocidadeAferida, hora) VALUES (
	01,
    'JKD3720',
    'aab343',
    402,
    1,
    '2005-02-12',
    000,
    '2005-02-12 12:30:00'
);

INSERT INTO PROPRIETARIO(cpf, nome, dataNascimento, sexo, rua, numero, bairro, complemento, cidade, estado, cep) VALUES (
	60027159167,
    'Arthur Thiago Benjamin Sales',
    '2000-01-09',
    'M',
    'Quadra QNO 18 Conjunto 66',
    '364',
    'Ceilândia Norte',
    'Casa 34',
    'Brasília',
    'DF',
    72260866
);

INSERT INTO telefone(cpf, numero) VALUES (
	60027159167,
    61998373459
);

INSERT INTO MODELO(codigoModelo, nomeModelo) VALUES (
	147963,
    '320 ELITE 1.3 16V'
);

INSERT INTO CATEGORIA(codigoCategoria, nomeCategoria) VALUES (
	02,
    'Automóvel'
);

INSERT INTO VEICULO(placa, cpf, codigoCategoria, codigoModelo, chassi, anoFabricacao, corPredominante) VALUES (
	'JIM2728',
    60027159167,
    02,
    147963,
    '7Nj9823d0GJZ71902',
    2009,
    'Cinza'
);

INSERT INTO LOCALIZACAO(codigoLocal, latitude, longitude, velocidadePermitida) VALUES (
	'abb777',
    54.125417,
    311.649218,
    80
);

INSERT INTO AGENTE_TRANSITO(matriculaFuncional, nomeAgente, dataContratacao) VALUES (
	500,
    'Gabriela Teresinha Costa',
    '2003-09-01'
);

INSERT INTO TIPOINFRACAO(codigoTipoInfracao, valorInfracao, descricao) VALUES (
	2,
    '200,00',
    'Farol dianteiro direito queimado'
);

INSERT INTO INFRACAO(idInfracao, placa, codigoLocal, matriculaFuncional, codigoTipoInfracao, data, velocidadeAferida, hora) VALUES (
	02,
    'JIM2728',
    'abb777',
    500,
    2,
    '2005-05-23',
    80,
    '2005-05-23 08:00:00'
);

INSERT INTO PROPRIETARIO(cpf, nome, dataNascimento, sexo, rua, numero, bairro, complemento, cidade, estado, cep) VALUES (
	47328518197,
    'Alana Heloisa Mariana Martins',
    '1987-01-04',
    'F',
    'Quadra Quadra 21A',
    '880',
    'Setor Residencial Leste',
    'Aprt 5 andar 2',
    'Brasília',
    'DF',
    73358655
);

INSERT INTO telefone(cpf, numero) VALUES (
	47328518197,
    61998445763
);

INSERT INTO MODELO(codigoModelo, nomeModelo) VALUES (
	159357,
    'X30 VAN 1.3 16V Mec.'
);

INSERT INTO CATEGORIA(codigoCategoria, nomeCategoria) VALUES (
	03,
    'Automóvel'
);

INSERT INTO VEICULO(placa, cpf, codigoCategoria, codigoModelo, chassi, anoFabricacao, corPredominante) VALUES (
	'JFA1586',
    47328518197,
    03,
    159357,
    '8Uwz7186gAhcm7119',
    2014,
    'Verde'
);

INSERT INTO LOCALIZACAO(codigoLocal, latitude, longitude, velocidadePermitida) VALUES (
	'aaa789',
    20.122479,
    102.139232,
    80
);

INSERT INTO AGENTE_TRANSITO(matriculaFuncional, nomeAgente, dataContratacao) VALUES (
	120,
    'Fernanda Stefany Nogueira',
    '2010-05-02'
);

INSERT INTO TIPOINFRACAO(codigoTipoInfracao, valorInfracao, descricao) VALUES (
	3,
    '293,47',
    'Não reduziu a velocidade nas proximidades de escolas'
);

INSERT INTO INFRACAO(idInfracao, placa, codigoLocal, matriculaFuncional, codigoTipoInfracao, data, velocidadeAferida, hora) VALUES (
	03,
    'JFA1586',
    'aaa789',
    120,
    3,
    '2012-02-11',
    80,
    '2012-02-11 11:50:00'
);

---------------
INSERT INTO PROPRIETARIO(cpf, nome, dataNascimento, sexo, rua, numero, bairro, complemento, cidade, estado, cep) VALUES (
	06140370209,
    'Rodrigo Muniz da Silva',
    '1998-05-09',
    'M',
    'Presidente Vargas',
    '430',
    'Setor Residencial Flamboyant',
    'Aprt 306 andar 4',
    'Goiãnia',
    'GO',
    64858365
);

INSERT INTO telefone(cpf, numero) VALUES (
    62993957878
);

INSERT INTO MODELO(codigoModelo, nomeModelo) VALUES (
	176327,
    'Sport -flex'
);

INSERT INTO CATEGORIA(codigoCategoria, nomeCategoria) VALUES (
	03,
    'Automóvel'
);

INSERT INTO VEICULO(placa, cpf, codigoCategoria, codigoModelo, chassi, anoFabricacao, corPredominante) VALUES (
	'QGA2589',
   06140370209,
    03,
   	176327,
    '3Tgk7186gCmcm3220',
    2019,
    'Prata'
);

INSERT INTO LOCALIZACAO(codigoLocal, latitude, longitude, velocidadePermitida) VALUES (
	'gbq344',
    21.123371,
    112.632432,
    80
);

INSERT INTO AGENTE_TRANSITO(matriculaFuncional, nomeAgente, dataContratacao) VALUES (
	120,
    'Fernanda Stefany Nogueira',
    '2010-05-02'
);

INSERT INTO TIPOINFRACAO(codigoTipoInfracao, valorInfracao, descricao) VALUES (
	3,
    '800,00',
    'Ultrapassem de sinal vermelho'
);

INSERT INTO INFRACAO(idInfracao, placa, codigoLocal, matriculaFuncional, codigoTipoInfracao, data, velocidadeAferida, hora) VALUES (
	03,
    'QGA2589',
    'gbq344',
    120,
    3,
    '2012-02-11',
    80,
    '2012-02-11 11:50:00'
);