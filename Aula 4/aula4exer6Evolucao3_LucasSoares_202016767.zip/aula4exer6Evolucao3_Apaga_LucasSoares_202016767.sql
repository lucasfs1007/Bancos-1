-- -----------     <<aula4exer6Evolucao3 >>     -------------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 29/10/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6Evolucao3
-- 
-- Alteracoes Evolucao 2 ..: 29/10/2023
--   => Criacao de novo Script para apagar as tabelas da base de dados aula4exer6Evolucao2
--
-- Alteracoes Evolucao 3 ..: 08/11/2023
--   => Reformulacao dos Scripts para apagar as tabelas da base de dados aula4exer6Evolucao3 na ordem adequada

-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer6Evolucao3;

DROP TABLE INFRACAO;
DROP TABLE TIPOINFRACAO;
DROP TABLE AGENTE_TRANSITO;
DROP TABLE LOCALIZACAO;
DROP TABLE VEICULO;
DROP TABLE CATEGORIA;
DROP TABLE MODELO;
DROP TABLE telefone;
DROP TABLE PROPRIETARIO;