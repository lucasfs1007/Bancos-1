-- -----------     << aula4exer6Evolucao3 >>     -------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 29/10/2023
-- Autor(es) ..............: Lucas Felipe Soares
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6Evolucao3
-- 
-- Alteracoes da evolucao 2 ..: 29/10/2023
--   => Criacao de nova tabela

-- Data Ultima Alteracao ..: 08/11/2023
--   => Ajuste na criacao da base de dados caso nao exista e revisao de todas as tabelas a serem criadas

-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer6Evolucao2;

USE aula4exer6Evolucao2;

CREATE TABLE PROPRIETARIO (
    cpf BIGINT(11) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    rua VARCHAR(40) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    complemento VARCHAR(50) NOT NULL,
    cidade VARCHAR(20) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep INT(8) NOT NULL,
    
    CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
);

CREATE TABLE telefone (
    cpf BIGINT(11) NOT NULL,
    numero BIGINT(14) NOT NULL,
    
    CONSTRAINT telefone_PK PRIMARY KEY (cpf, numero),
    CONSTRAINT telefone_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO(cpf)
);

CREATE TABLE MODELO (
    codigoModelo INT(6) NOT NULL,
    nomeModelo VARCHAR(20) NOT NULL,
    
    CONSTRAINT MODELO_PK PRIMARY KEY (codigoModelo)
);

CREATE TABLE CATEGORIA (
    codigoCategoria INT(2) NOT NULL,
    nomeCategoria VARCHAR(20) NOT NULL,
    
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (codigoCategoria)
);

CREATE TABLE VEICULO (
    placa VARCHAR(7) NOT NULL,
    cpf BIGINT(11) NOT NULL,
    codigoCategoria INT(2) NOT NULL,
    codigoModelo INT(6) NOT NULL,
    chassi VARCHAR(17) NOT NULL,
    anoFabricacao INT(4) NOT NULL,
    corPredominante VARCHAR(20) NOT NULL,
    
    CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
    CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf),
    CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codigoCategoria)
    REFERENCES CATEGORIA(codigoCategoria),
    CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codigoModelo)
    REFERENCES MODELO(codigoModelo)
);

CREATE TABLE LOCALIZACAO (
    codigoLocal VARCHAR(20) NOT NULL,
    latitude DECIMAL(8,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    velocidadePermitida INT(3) NOT NULL,
    
    CONSTRAINT LOCALIZACAO_PK PRIMARY KEY (codigoLocal)
);

CREATE TABLE AGENTE_TRANSITO (
    matriculaFuncional BIGINT NOT NULL,
    nomeAgente VARCHAR(100) NOT NULL,
    dataContratacao DATE NOT NULL,
    
    CONSTRAINT AGENTE_TRANSITO PRIMARY KEY (matriculaFuncional)
);

CREATE TABLE TIPOINFRACAO (
    codigoTipoInfracao INT NOT NULL,
    valorInfracao VARCHAR(100) NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    
    CONSTRAINT TIPOINFRACAO_PK PRIMARY KEY (codigoTipoInfracao)
);

CREATE TABLE INFRACAO (
    idInfracao BIGINT NOT NULL,
    placa VARCHAR(7) NOT NULL,
    codigoLocal VARCHAR(20) NOT NULL,
    matriculaFuncional BIGINT NOT NULL,
    codigoTipoInfracao INT NOT NULL,
    data DATE NOT NULL,
    velocidadeAferida INT(3) NOT NULL,
    hora TIMESTAMP NOT NULL,
    
    CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
    CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa)
    REFERENCES VEICULO (placa),
    CONSTRAINT INFRACAO_LOCALIZACAO_FK FOREIGN KEY (codigoLocal)
    REFERENCES LOCALIZACAO (codigoLocal),
    CONSTRAINT INFRACAO_AGENTE_TRANSITO_FK FOREIGN KEY (matriculaFuncional)
    REFERENCES AGENTE_TRANSITO (matriculaFuncional),
    CONSTRAINT INFRACAO_TIPOINFRACAO_FK FOREIGN KEY (codigoTipoInfracao)
    REFERENCES TIPOINFRACAO (codigoTipoInfracao)
);